<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\ucp;

class main_info
{
	/**
	 * @return array
	 */
	public function module()
	{
		return [
			'filename'	=> '\stoker\chat\ucp\main_module',
			'title'		=> 'UCP_STOKER_CHAT_TITLE',
			'modes'		=> [
				'settings'	=> [
					'title'	=> 'UCP_STOKER_CHAT_TITLE',
					'auth'	=> 'ext_stoker/chat && acl_u_stoker_chat_view',
					'cat'	=> ['UCP_PREFS'],
				],
			],
		];
	}
}
