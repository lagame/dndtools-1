<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\ucp;

class main_module
{
	/** @var string */
	public $u_action;

	/** @var string */
	public $tpl_name;

	/** @var string */
	public $page_title;

	/**
	 * @param string $id
	 * @param string $mode
	 * @return void
	 */
	public function main($id, $mode): void
	{
		global $phpbb_container;

		$controller = $phpbb_container->get('stoker.chat.ucp_controller');
		$controller->set_page_url($this->u_action);

		$language = $phpbb_container->get('language');

		switch ($mode)
		{
			case 'settings':
				$this->tpl_name = 'ucp_chat_body';
				$this->page_title = $language->lang('UCP_STOKER_CHAT_TITLE');
				$controller->display_settings();
			break;
		}
	}
}
