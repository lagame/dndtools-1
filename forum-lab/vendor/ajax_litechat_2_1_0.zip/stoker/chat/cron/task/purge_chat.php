<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\cron\task;

use phpbb\config\config;
use phpbb\db\driver\driver_interface;

class purge_chat extends \phpbb\cron\task\base
{
	/** @var config */
	protected $config;

	/** @var driver_interface */
	protected $db;

	/** @var string */
	protected $chat_table;

	/** @var int Minimum number of newest messages always retained, so the chat is never left empty. */
	const KEEP_MINIMUM = 20;

	/**
	 * @param config			$config
	 * @param driver_interface	$db
	 * @param string			$chat_table
	 */
	public function __construct(config $config, driver_interface $db, string $chat_table)
	{
		$this->config = $config;
		$this->db = $db;
		$this->chat_table = $chat_table;
	}

	/**
	 * Always returns true after a day has passed since last run.
	 * Tombstones from soft-deletes need cleanup regardless of purge_days.
	 *
	 * @return bool
	 */
	public function should_run()
	{
		$last_run = (int) $this->config['stoker_chat_purge_last_run'];

		return ($last_run < strtotime('-1 day'));
	}

	/**
	 * @return void
	 */
	public function run(): void
	{
		// Purge soft-deleted tombstones older than 24 hours.
		// Younger tombstones are kept so open polling clients learn the deletion
		// and remove the message from their DOM on the next poll.
		$tombstone_cutoff = time() - 86400;
		$sql = 'DELETE FROM ' . $this->chat_table . '
			WHERE deleted = 1
				AND deleted_time < ' . (int) $tombstone_cutoff;
		$this->db->sql_query($sql);

		// Age-based purge (only when enabled). Always keep the newest KEEP_MINIMUM
		// visible messages, even if they're older than the cutoff, so the chat is never left empty.
		$purge_days = (int) $this->config['stoker_chat_purge_days'];
		if ($purge_days > 0)
		{
			$cutoff = time() - ($purge_days * 86400);

			// Find the message_id of the KEEP_MINIMUM-th newest visible row. Anything older
			// than that AND older than the cutoff is eligible for deletion.
			$sql = 'SELECT message_id
				FROM ' . $this->chat_table . '
				WHERE deleted = 0
				ORDER BY message_id DESC';
			$result = $this->db->sql_query_limit($sql, 1, self::KEEP_MINIMUM - 1);
			$threshold_row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			// Fewer than KEEP_MINIMUM visible rows in the table — nothing to purge.
			if ($threshold_row !== false)
			{
				$threshold_id = (int) $threshold_row['message_id'];

				$sql = 'DELETE FROM ' . $this->chat_table . '
					WHERE message_time < ' . (int) $cutoff . '
						AND message_id < ' . (int) $threshold_id . '
						AND deleted = 0';
				$this->db->sql_query($sql);
			}
		}

		$this->config->set('stoker_chat_purge_last_run', (string) time(), false);
	}
}
