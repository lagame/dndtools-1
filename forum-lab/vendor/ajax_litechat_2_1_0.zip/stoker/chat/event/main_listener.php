<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\event;

use phpbb\auth\auth;
use phpbb\controller\helper;
use phpbb\event\data;
use phpbb\language\language;
use phpbb\template\template;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class main_listener implements EventSubscriberInterface
{
	/** @var auth */
	protected $auth;

	/** @var helper */
	protected $helper;

	/** @var language */
	protected $language;

	/** @var template */
	protected $template;

	/** @var string */
	protected $php_ext;

	/**
	 * @param auth				$auth
	 * @param helper			$helper
	 * @param language			$language
	 * @param template			$template
	 * @param string			$php_ext
	 */
	public function __construct(auth $auth, helper $helper, language $language, template $template, string $php_ext)
	{
		$this->auth = $auth;
		$this->helper = $helper;
		$this->language = $language;
		$this->template = $template;
		$this->php_ext = $php_ext;
	}

	/**
	 * @return array
	 */
	static public function getSubscribedEvents()
	{
		return [
			'core.page_header' => 'add_navbar_link',
			'core.permissions' => 'add_permissions',
			'core.viewonline_overwrite_location' => 'add_chat_viewonline',
		];
	}

	/**
	 * Assign navbar template vars on every page
	 *
	 * @return void
	 */
	public function add_navbar_link(): void
	{
		if (!$this->auth->acl_get('u_stoker_chat_view'))
		{
			return;
		}

		$this->language->add_lang('common', 'stoker/chat');

		$this->template->assign_vars([
			'U_STOKER_CHAT_PAGE' => $this->helper->route('stoker_chat_page'),
		]);
	}

	/**
	 * Add chat permissions
	 *
	 * @param data $event
	 * @return void
	 */
	public function add_permissions(data $event): void
	{
		$permissions = $event['permissions'];

		$permissions['u_stoker_chat_view'] = ['lang' => 'ACL_U_STOKER_CHAT_VIEW', 'cat' => 'misc'];
		$permissions['u_stoker_chat_use'] = ['lang' => 'ACL_U_STOKER_CHAT_USE', 'cat' => 'misc'];
		$permissions['u_stoker_chat_edit'] = ['lang' => 'ACL_U_STOKER_CHAT_EDIT', 'cat' => 'misc'];
		$permissions['u_stoker_chat_delete'] = ['lang' => 'ACL_U_STOKER_CHAT_DELETE', 'cat' => 'misc'];
		$permissions['u_stoker_chat_quote'] = ['lang' => 'ACL_U_STOKER_CHAT_QUOTE', 'cat' => 'misc'];
		$permissions['u_stoker_chat_like'] = ['lang' => 'ACL_U_STOKER_CHAT_LIKE', 'cat' => 'misc'];
		$permissions['u_stoker_chat_noflood'] = ['lang' => 'ACL_U_STOKER_CHAT_NOFLOOD', 'cat' => 'misc'];
		$permissions['m_stoker_chat_moderate'] = ['lang' => 'ACL_M_STOKER_CHAT_MODERATE', 'cat' => 'misc'];

		$event['permissions'] = $permissions;
	}

	/**
	 * @param data $event
	 * @return void
	 */
	public function add_chat_viewonline(data $event): void
	{
		$page = (string) ($event['row']['session_page'] ?? '');
		$route = 'app.' . $this->php_ext . '/chat';

		// Match /chat, /chat/... and /chat?... only, not other routes that start with /chat
		if ($page === $route || strpos($page, $route . '/') === 0 || strpos($page, $route . '?') === 0)
		{
			$this->language->add_lang('common', 'stoker/chat');
			$event['location'] = $this->language->lang('VIEWONLINE_STOKER_CHAT');
			$event['location_url'] = $this->helper->route('stoker_chat_page');
		}
	}
}
