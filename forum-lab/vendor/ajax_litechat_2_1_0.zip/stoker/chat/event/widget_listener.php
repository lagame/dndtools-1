<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\event;

use phpbb\auth\auth;
use phpbb\collapsiblecategories\operator\operator;
use phpbb\config\config;
use phpbb\template\template;
use phpbb\user;
use stoker\chat\core\chat_helper;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Renders the chat widget on the forum index and the Stoker Portal.
 * Depends on chat_helper rather than the chat controller, so the text
 * formatter services are not loaded on index and portal page views.
 */
class widget_listener implements EventSubscriberInterface
{
	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var template */
	protected $template;

	/** @var user */
	protected $user;

	/** @var chat_helper */
	protected $chat_helper;

	/** @var operator|null */
	protected $cc_operator;

	/**
	 * @param auth				$auth
	 * @param config			$config
	 * @param template			$template
	 * @param user				$user
	 * @param chat_helper		$chat_helper
	 * @param operator|null		$cc_operator
	 */
	public function __construct(auth $auth, config $config, template $template, user $user, chat_helper $chat_helper, ?operator $cc_operator = null)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->template = $template;
		$this->user = $user;
		$this->chat_helper = $chat_helper;
		$this->cc_operator = $cc_operator;
	}

	/**
	 * @return array
	 */
	static public function getSubscribedEvents()
	{
		return [
			'core.index_modify_page_title' => 'load_chat_on_index',
			'stoker.portal.main_controller_render_template_before' => 'load_chat_on_portal',
		];
	}

	/**
	 * Load chat widget on the forum index
	 *
	 * @return void
	 */
	public function load_chat_on_index(): void
	{
		// ACP gate: a board-wide off switch cannot be overridden by a user.
		if (!(int) $this->config['stoker_chat_index_enable'])
		{
			return;
		}

		if (!$this->auth->acl_get('u_stoker_chat_view'))
		{
			return;
		}

		if (!$this->resolve('user_stoker_chat_index_enable', 'stoker_chat_index_enable'))
		{
			return;
		}

		$position = $this->resolve('user_stoker_chat_index_pos', 'stoker_chat_index_position');

		$this->template->assign_vars($this->chat_helper->get_chat_vars(false));

		$this->template->assign_vars([
			'S_STOKER_CHAT_INDEX'			=> true,
			'S_STOKER_CHAT_INDEX_TOP'		=> $position === 0,
			'S_STOKER_CHAT_INDEX_BOTTOM'	=> $position === 1,
		]);

		if ($this->cc_operator !== null)
		{
			$ccid = 'stoker_chat_index';
			$this->template->assign_vars([
				'S_STOKER_CHAT_HIDDEN'	=> $this->cc_operator->is_collapsed($ccid),
				'U_STOKER_CHAT_COLLAPSE_URL'	=> $this->cc_operator->get_collapsible_link($ccid),
			]);
		}
	}

	/**
	 * Load chat widget on the Stoker Portal
	 *
	 * @return void
	 */
	public function load_chat_on_portal(): void
	{
		// ACP gate: a board-wide off switch cannot be overridden by a user.
		if (!(int) $this->config['stoker_chat_portal_enable'])
		{
			return;
		}

		if (!$this->auth->acl_get('u_stoker_chat_view'))
		{
			return;
		}

		if (!$this->resolve('user_stoker_chat_portal_enable', 'stoker_chat_portal_enable'))
		{
			return;
		}

		$position = $this->resolve('user_stoker_chat_portal_pos', 'stoker_chat_portal_position');

		$this->template->assign_vars($this->chat_helper->get_chat_vars(false));

		$this->template->assign_vars([
			'S_STOKER_CHAT_PORTAL'			=> true,
			'S_STOKER_CHAT_PORTAL_TOP'		=> $position === 0,
			'S_STOKER_CHAT_PORTAL_MIDDLE'	=> $position === 1,
			'S_STOKER_CHAT_PORTAL_BOTTOM'	=> $position === 2,
		]);

		if ($this->cc_operator !== null)
		{
			$ccid = 'stoker_chat_portal';
			$this->template->assign_vars([
				'S_STOKER_CHAT_HIDDEN'	=> $this->cc_operator->is_collapsed($ccid),
				'U_STOKER_CHAT_COLLAPSE_URL'	=> $this->cc_operator->get_collapsible_link($ccid),
			]);
		}
	}

	/**
	 * Resolve a per-user override against the board default. A stored value of
	 * -1 means "use board default", any other value overrides it.
	 *
	 * @param string $user_key
	 * @param string $config_key
	 * @return int
	 */
	private function resolve(string $user_key, string $config_key): int
	{
		$value = isset($this->user->data[$user_key]) ? (int) $this->user->data[$user_key] : -1;

		return $value === -1 ? (int) $this->config[$config_key] : $value;
	}
}
