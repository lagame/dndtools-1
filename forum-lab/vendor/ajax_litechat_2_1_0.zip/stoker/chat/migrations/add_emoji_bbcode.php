<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class add_emoji_bbcode extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\install_data'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		$emojis = [
			':-)'			=> '😊',
			':)'			=> '😊',
			':-D'			=> '😄',
			':D'			=> '😄',
			':-('			=> '😞',
			':('			=> '😞',
			';-)'			=> '😉',
			';)'			=> '😉',
			':-P'			=> '😛',
			':P'			=> '😛',
			':-O'			=> '😮',
			':O'			=> '😮',
			":'-("			=> '😢',
			":'("			=> '😢',
			':-*'			=> '😘',
			':*'			=> '😘',
			'B-)'			=> '😎',
			'B)'			=> '😎',
			'>:-)'			=> '😈',
			'>:)'			=> '😈',
			'xD'			=> '🤣',
			'XD'			=> '🤣',
			'<3'			=> '❤️',
			':100:'			=> '💯',
			':clown:'		=> '🤡',
			':coffee:'		=> '☕',
			':beer:'		=> '🍺',
			':champagne:'	=> '🍾',
			':drink:'		=> '🍹',
			':sun:'			=> '☀️',
			':crying:'		=> '😭',
			':sparkles:'	=> '✨',
			':finger:'		=> '👉',
			':eyes:'		=> '👀',
			':tired:'		=> '😴',
			':notfunny:'	=> '😒',
		];

		$disabled_bbcodes = ['code', 'img', 'size', 'list', 'flash', 'attachment'];

		$payload = json_encode([
			'emojis'			=> (object) $emojis,
			'disabled_bbcodes'	=> $disabled_bbcodes,
		]);

		return [
			['config_text.add', ['stoker_chat_emoji_bbcode', $payload]],

			['module.add', ['acp', 'ACP_STOKER_CHAT_TITLE', [
				'module_basename'	=> '\stoker\chat\acp\main_module',
				'modes'				=> ['emoji_bbcode'],
			]]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['module.remove', ['acp', 'ACP_STOKER_CHAT_TITLE', [
				'module_basename'	=> '\stoker\chat\acp\main_module',
				'modes'				=> ['emoji_bbcode'],
			]]],

			['config_text.remove', ['stoker_chat_emoji_bbcode']],
		];
	}
}
