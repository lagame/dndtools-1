<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class convert_emoji_bbcode extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\add_emoji_bbcode'];
	}

	/**
	 * Rewrite the stored emoji set into the grouped {emoji, shortcodes[], in_picker}
	 * shape. Unconditional: on a fresh install this re-states the value already seeded
	 * by add_emoji_bbcode; on an existing board it replaces the legacy flat map.
	 *
	 * @return array
	 */
	public function update_data()
	{
		$payload = json_encode([
			'emojis'			=> $this->grouped_emojis(),
			'disabled_bbcodes'	=> ['code', 'img', 'size', 'list', 'flash', 'attachment'],
		]);

		return [
			['config_text.update', ['stoker_chat_emoji_bbcode', $payload]],
		];
	}

	/**
	 * The default emoji set in grouped form, every entry flagged for the picker.
	 *
	 * @return array
	 */
	protected function grouped_emojis(): array
	{
		return [
			['emoji' => '😊', 'shortcodes' => [':-)', ':)'], 'in_picker' => true],
			['emoji' => '😄', 'shortcodes' => [':-D', ':D'], 'in_picker' => true],
			['emoji' => '😞', 'shortcodes' => [':-(', ':('], 'in_picker' => true],
			['emoji' => '😉', 'shortcodes' => [';-)', ';)'], 'in_picker' => true],
			['emoji' => '😛', 'shortcodes' => [':-P', ':P'], 'in_picker' => true],
			['emoji' => '😮', 'shortcodes' => [':-O', ':O'], 'in_picker' => true],
			['emoji' => '😢', 'shortcodes' => [":'-(", ":'("], 'in_picker' => true],
			['emoji' => '😘', 'shortcodes' => [':-*', ':*'], 'in_picker' => true],
			['emoji' => '😎', 'shortcodes' => ['B-)', 'B)'], 'in_picker' => true],
			['emoji' => '😈', 'shortcodes' => ['>:-)', '>:)'], 'in_picker' => true],
			['emoji' => '🤣', 'shortcodes' => ['xD', 'XD'], 'in_picker' => true],
			['emoji' => '❤️', 'shortcodes' => ['<3'], 'in_picker' => true],
			['emoji' => '💯', 'shortcodes' => [':100:'], 'in_picker' => true],
			['emoji' => '🤡', 'shortcodes' => [':clown:'], 'in_picker' => true],
			['emoji' => '☕', 'shortcodes' => [':coffee:'], 'in_picker' => true],
			['emoji' => '🍺', 'shortcodes' => [':beer:'], 'in_picker' => true],
			['emoji' => '🍾', 'shortcodes' => [':champagne:'], 'in_picker' => true],
			['emoji' => '🍹', 'shortcodes' => [':drink:'], 'in_picker' => true],
			['emoji' => '☀️', 'shortcodes' => [':sun:'], 'in_picker' => true],
			['emoji' => '😭', 'shortcodes' => [':crying:'], 'in_picker' => true],
			['emoji' => '✨', 'shortcodes' => [':sparkles:'], 'in_picker' => true],
			['emoji' => '👉', 'shortcodes' => [':finger:'], 'in_picker' => true],
			['emoji' => '👀', 'shortcodes' => [':eyes:'], 'in_picker' => true],
			['emoji' => '😴', 'shortcodes' => [':tired:'], 'in_picker' => true],
			['emoji' => '😒', 'shortcodes' => [':notfunny:'], 'in_picker' => true],
		];
	}
}
