<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class ucp_prefs extends \phpbb\db\migration\migration
{
	/**
	 * @return bool
	 */
	public function effectively_installed()
	{
		return $this->db_tools->sql_column_exists($this->table_prefix . 'users', 'user_stoker_chat_action_bar');
	}

	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\action_bar_mode'];
	}

	/**
	 * @return array
	 */
	public function update_schema()
	{
		return [
			'add_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_index_enable'		=> ['TINT:4', -1],
					'user_stoker_chat_index_pos'		=> ['TINT:4', -1],
					'user_stoker_chat_portal_enable'	=> ['TINT:4', -1],
					'user_stoker_chat_portal_pos'		=> ['TINT:4', -1],
					'user_stoker_chat_action_bar'		=> ['TINT:4', -1],
				],
			],
			'drop_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_show',
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function revert_schema()
	{
		return [
			'add_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_show' => ['BOOL', 1],
				],
			],
			'drop_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_index_enable',
					'user_stoker_chat_index_pos',
					'user_stoker_chat_portal_enable',
					'user_stoker_chat_portal_pos',
					'user_stoker_chat_action_bar',
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['module.add', ['ucp', 'UCP_PREFS', [
				'module_basename'	=> '\stoker\chat\ucp\main_module',
				'modes'				=> ['settings'],
			]]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['module.remove', ['ucp', 'UCP_PREFS', [
				'module_basename'	=> '\stoker\chat\ucp\main_module',
				'modes'				=> ['settings'],
			]]],
		];
	}
}
