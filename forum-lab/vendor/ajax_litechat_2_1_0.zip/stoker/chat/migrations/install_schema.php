<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class install_schema extends \phpbb\db\migration\migration
{
	/**
	 * @return bool
	 */
	public function effectively_installed()
	{
		return $this->db_tools->sql_table_exists($this->table_prefix . 'stoker_chat_messages');
	}

	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\phpbb\db\migration\data\v330\v330'];
	}

	/**
	 * @return array
	 */
	public function update_schema()
	{
		return [
			'add_tables' => [
				$this->table_prefix . 'stoker_chat_messages' => [
					'COLUMNS' => [
						'message_id'	=> ['ULINT', null, 'auto_increment'],
						'user_id'		=> ['UINT', 0],
						'message'		=> ['MTEXT_UNI', ''],
						'message_time'	=> ['TIMESTAMP', 0],
						'edit_time'		=> ['TIMESTAMP', 0],
						'deleted'		=> ['BOOL', 0],
						'deleted_time'	=> ['TIMESTAMP', 0],
					],
					'PRIMARY_KEY' => 'message_id',
					'KEYS' => [
						'message_time'			=> ['INDEX', ['message_time']],
						'user_id_time'			=> ['INDEX', ['user_id', 'message_time']],
						'deleted_message_id'	=> ['INDEX', ['deleted', 'message_id']],
					],
				],
			],
			'add_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_show' => ['BOOL', 1],
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function revert_schema()
	{
		return [
			'drop_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_show',
				],
			],
			'drop_tables' => [
				$this->table_prefix . 'stoker_chat_messages',
			],
		];
	}
}
