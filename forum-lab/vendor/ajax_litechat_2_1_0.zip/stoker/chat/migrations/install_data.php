<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class install_data extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\install_schema'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			// Config
			['config.add', ['stoker_chat_index_enable', 1]],
			['config.add', ['stoker_chat_index_position', 1]],
			['config.add', ['stoker_chat_portal_enable', 1]],
			['config.add', ['stoker_chat_portal_position', 1]],
			['config.add', ['stoker_chat_poll_interval', 5]],
			['config.add', ['stoker_chat_max_messages', 50]],
			['config.add', ['stoker_chat_max_length', 500]],
			['config.add', ['stoker_chat_flood_interval', 2]],
			['config.add', ['stoker_chat_purge_days', 30]],
			['config.add', ['stoker_chat_purge_last_run', 0, true]],
			['config.add', ['stoker_chat_initial_load', 10]],
			['config.add', ['stoker_chat_inactivity_minutes', 10]],
			['config.add', ['stoker_chat_tabhidden_seconds', 10]],

			// Permissions
			['permission.add', ['u_stoker_chat_view', true]],
			['permission.add', ['u_stoker_chat_use', true]],
			['permission.add', ['u_stoker_chat_edit', true]],
			['permission.add', ['u_stoker_chat_delete', true]],
			['permission.add', ['u_stoker_chat_quote', true]],
			['permission.add', ['u_stoker_chat_like', true]],
			['permission.add', ['u_stoker_chat_noflood', true]],
			['permission.add', ['m_stoker_chat_moderate', true]],

			// Guests: view only (explicitly denied by default)
			['permission.permission_set', ['GUESTS', 'u_stoker_chat_view', 'group', false]],

			// Registered users: view, use, edit own, delete own, quote, like
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_view', 'group']],
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_use', 'group']],
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_edit', 'group']],
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_delete', 'group']],
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_quote', 'group']],
			['permission.permission_set', ['REGISTERED', 'u_stoker_chat_like', 'group']],

			// Global moderators: all of the above plus noflood and moderate
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_view', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_use', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_edit', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_delete', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_quote', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_like', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'u_stoker_chat_noflood', 'group']],
			['permission.permission_set', ['GLOBAL_MODERATORS', 'm_stoker_chat_moderate', 'group']],

			// Administrators: everything
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_view', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_use', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_edit', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_delete', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_quote', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_like', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'u_stoker_chat_noflood', 'group']],
			['permission.permission_set', ['ADMINISTRATORS', 'm_stoker_chat_moderate', 'group']],

			// ACP module
			['module.add', ['acp', 'ACP_CAT_DOT_MODS', 'ACP_STOKER_CHAT_TITLE']],
			['module.add', ['acp', 'ACP_STOKER_CHAT_TITLE', [
				'module_basename'=> '\stoker\chat\acp\main_module',
				'modes'	=> ['settings'],
			]]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			// ACP module — remove the child mode first (by basename), then the category
			['module.remove', ['acp', 'ACP_STOKER_CHAT_TITLE', [
				'module_basename'	=> '\stoker\chat\acp\main_module',
				'modes'	=> ['settings'],
			]]],
			['module.remove', ['acp', 'ACP_CAT_DOT_MODS', 'ACP_STOKER_CHAT_TITLE']],

			// Permissions (removing an auth option removes all role/group assignments)
			['permission.remove', ['u_stoker_chat_view']],
			['permission.remove', ['u_stoker_chat_use']],
			['permission.remove', ['u_stoker_chat_edit']],
			['permission.remove', ['u_stoker_chat_delete']],
			['permission.remove', ['u_stoker_chat_quote']],
			['permission.remove', ['u_stoker_chat_like']],
			['permission.remove', ['u_stoker_chat_noflood']],
			['permission.remove', ['m_stoker_chat_moderate']],

			// Config
			['config.remove', ['stoker_chat_index_enable']],
			['config.remove', ['stoker_chat_index_position']],
			['config.remove', ['stoker_chat_portal_enable']],
			['config.remove', ['stoker_chat_portal_position']],
			['config.remove', ['stoker_chat_poll_interval']],
			['config.remove', ['stoker_chat_max_messages']],
			['config.remove', ['stoker_chat_max_length']],
			['config.remove', ['stoker_chat_flood_interval']],
			['config.remove', ['stoker_chat_purge_days']],
			['config.remove', ['stoker_chat_purge_last_run']],
			['config.remove', ['stoker_chat_initial_load']],
			['config.remove', ['stoker_chat_inactivity_minutes']],
			['config.remove', ['stoker_chat_tabhidden_seconds']],
		];
	}
}
