<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class action_bar_mode extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\convert_emoji_bbcode'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['config.add', ['stoker_chat_action_bar', 0]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['config.remove', ['stoker_chat_action_bar']],
		];
	}
}
