<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\migrations;

class message_flow extends \phpbb\db\migration\migration
{
	/**
	 * @return bool
	 */
	public function effectively_installed()
	{
		return $this->db_tools->sql_column_exists($this->table_prefix . 'users', 'user_stoker_chat_flow');
	}

	/**
	 * @return array
	 */
	static public function depends_on()
	{
		return ['\stoker\chat\migrations\ucp_prefs'];
	}

	/**
	 * @return array
	 */
	public function update_schema()
	{
		return [
			'add_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_flow' => ['TINT:4', -1],
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function revert_schema()
	{
		return [
			'drop_columns' => [
				$this->table_prefix . 'users' => [
					'user_stoker_chat_flow',
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['config.add', ['stoker_chat_flow', 0]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['config.remove', ['stoker_chat_flow']],
		];
	}
}
