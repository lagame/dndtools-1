(function($) {
	'use strict';

	var $chat = $('#stoker-chat');
	if (!$chat.length) {
		return;
	}

	var fetchUrl = $chat.data('fetch-url');
	var postUrl = $chat.data('post-url');
	var editUrl = $chat.data('edit-url');
	var deleteUrl = $chat.data('delete-url');
	var pollInterval = parseInt($chat.data('poll-interval'), 10) * 1000;
	var maxLength = parseInt($chat.data('max-length'), 10);
	var maxMessages = parseInt($chat.data('max-messages'), 10) || 0;
	var chatHash = $chat.data('hash');
	var errorText = $chat.data('error-text');
	var tooLongText = $chat.data('too-long');
	var deleteConfirm = $chat.data('delete-confirm');
	var confirmYes = $chat.data('confirm-yes');
	var confirmNo = $chat.data('confirm-no');
	var noMessages = $chat.data('no-messages');
	var editLabel = $chat.data('edit-label');
	var deleteLabel = $chat.data('delete-label');
	var quoteLabel = $chat.data('quote-label');
	var likeLabel = $chat.data('like-label');
	var editSave = $chat.data('edit-save');
	var editCancel = $chat.data('edit-cancel');
	var editedLabel = $chat.data('edited-label');
	var menuLabel = $chat.data('menu-label');
	var loadOlderLabel = $chat.data('load-older');
	var loadOlderLoading = $chat.data('load-older-loading');
	var inactivityMs = parseInt($chat.data('inactivity-ms'), 10) || 0;

	// Message flow direction. 1 = newest at top (messages slide down from the top),
	// otherwise newest at bottom (default). Resolved server-side from the board
	// default and the per-user override, delivered via the data-flow attribute.
	var topMode = parseInt($chat.data('flow'), 10) === 1;

	var lastId = 0;
	var lastCheck = 0;
	var pollTimer = null;
	var isVisible = !document.hidden;
	var isBusy = false;
	var isLoadingOlder = false;
	var hasMore = false;
	var isLocked = false;
	var lastActivity = Date.now();
	var lastActivityReset = 0;
	var inactivityTimer = null;
	var hideLockTimer = null;
	var tabHiddenMs = parseInt($chat.data('tabhidden-ms'), 10) || 0;
	var forceScrollOnNext = false;
	var refreshQueued = false;
	var isHalted = false;
	var addonActions = [];

	var $messages = $('#stoker-chat-messages');
	var $input = $('#stoker-chat-text');
	var $send = $('#stoker-chat-send');
	var $counter = $('#stoker-chat-counter');
	var $lockdown = $('#stoker-chat-lockdown');

	// BBCodes disabled in chat (ACP-configurable, delivered via the data-disabled-bbcodes attribute).
	// Client-generated BBCode (quote, like, username click) must not use them, the server rejects such posts.
	var disabledBbcodes = $chat.data('disabled-bbcodes') || [];
	if (typeof disabledBbcodes === 'string') {
		try {
			disabledBbcodes = JSON.parse(disabledBbcodes);
		} catch (e) {
			disabledBbcodes = [];
		}
	}
	if (!Array.isArray(disabledBbcodes)) {
		disabledBbcodes = [];
	}
	disabledBbcodes = disabledBbcodes.map(function(tag) {
		return String(tag).toLowerCase();
	});

	function isBbcodeDisabled(tag) {
		return disabledBbcodes.indexOf(tag) !== -1;
	}

	// Length in Unicode code points, matching the server's utf8_strlen().
	function cpLength(text) {
		return Array.from(text == null ? '' : String(text)).length;
	}

	// Emoticon shortcodes (ACP-configurable, delivered via the data-emoji-map attribute)
	var emoticonMap = $chat.data('emoji-map') || {};
	if (typeof emoticonMap === 'string') {
		try {
			emoticonMap = JSON.parse(emoticonMap);
		} catch (e) {
			emoticonMap = {};
		}
	}
	if (typeof emoticonMap !== 'object' || emoticonMap === null) {
		emoticonMap = {};
	}

	var emoticonRegex = (function() {
		var keys = Object.keys(emoticonMap).sort(function(a, b) {
			return b.length - a.length;
		});
		if (!keys.length) {
			return null;
		}
		var escaped = keys.map(function(k) {
			return k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
		});
		return new RegExp('(^|\\s)(' + escaped.join('|') + ')(?=\\s|$)', 'g');
	}());

	function convertEmoticons(text) {
		if (!emoticonRegex) {
			return text;
		}
		return text.replace(emoticonRegex, function(_, lead, code) {
			return lead + emoticonMap[code];
		});
	}

	// One emoji: a flag (regional indicator pair), a keycap, or a pictograph shown as emoji
	// (emoji presentation by default, a modifier base with skin tone, or forced by U+FE0F),
	// optionally a subdivision tag sequence, then any ZWJ-joined parts. Text-presentation
	// symbols such as ©, ® and ™ do not match.
	var emojiRegex = /(?:\p{Regional_Indicator}{2}|[0-9#*]️?⃣|(?:\p{Emoji_Modifier_Base}\p{Emoji_Modifier}|\p{Emoji_Presentation}\p{Emoji_Modifier}?|\p{Extended_Pictographic}️)(?:[\u{E0020}-\u{E007E}]+\u{E007F})?)(?:‍\p{Extended_Pictographic}️?\p{Emoji_Modifier}?️?)*/gu;

	function wrapEmoji($el) {
		if (!$el || !$el.length) {
			return;
		}
		$el.each(function() {
			walkAndWrap(this);
		});
	}

	function walkAndWrap(node) {
		var child = node.firstChild;
		while (child) {
			var next = child.nextSibling;
			if (child.nodeType === 1) {
				// Element — skip if it's already an emoji wrapper, otherwise recurse.
				if (!(child.className && child.className.indexOf && child.className.indexOf('stoker-chat-emoji') !== -1)) {
					walkAndWrap(child);
				}
			} else if (child.nodeType === 3 && child.nodeValue && emojiRegex.test(child.nodeValue)) {
				replaceTextNodeWithWrappedEmoji(child);
			}
			child = next;
		}
	}

	function replaceTextNodeWithWrappedEmoji(textNode) {
		var text = textNode.nodeValue;
		var frag = document.createDocumentFragment();
		var lastIndex = 0;
		var m;

		// Reset because the regex is /g and shared across calls.
		emojiRegex.lastIndex = 0;
		while ((m = emojiRegex.exec(text)) !== null) {
			if (m.index > lastIndex) {
				frag.appendChild(document.createTextNode(text.substring(lastIndex, m.index)));
			}
			var span = document.createElement('span');
			span.className = 'stoker-chat-emoji';
			span.appendChild(document.createTextNode(m[0]));
			frag.appendChild(span);
			lastIndex = m.index + m[0].length;
		}
		if (lastIndex < text.length) {
			frag.appendChild(document.createTextNode(text.substring(lastIndex)));
		}
		textNode.parentNode.replaceChild(frag, textNode);
	}

	// Emoji picker (desktop convenience button). Populated from the in_picker list; the
	// button itself is shown only on desktop via CSS and only when the list is non-empty.
	var pickerEmojis = $chat.data('picker-emojis') || [];
	if (typeof pickerEmojis === 'string') {
		try {
			pickerEmojis = JSON.parse(pickerEmojis);
		} catch (e) {
			pickerEmojis = [];
		}
	}
	if (!Array.isArray(pickerEmojis)) {
		pickerEmojis = [];
	}

	var $emojiBtn = $('#stoker-chat-emoji-btn');
	var $emojiPicker = $('#stoker-chat-emoji-picker');

	function buildEmojiPicker() {
		if (!$emojiPicker.length || !pickerEmojis.length) {
			return;
		}
		var html = '';
		for (var i = 0; i < pickerEmojis.length; i++) {
			html += '<button type="button" class="stoker-chat-emoji-choice" role="menuitem" tabindex="-1">' + escapeHtml(pickerEmojis[i]) + '</button>';
		}
		$emojiPicker.html(html);
		$chat.addClass('has-emoji-picker');
	}

	function toggleEmojiPicker(force) {
		var show = (typeof force === 'boolean') ? force : $emojiPicker.prop('hidden');
		$emojiPicker.prop('hidden', !show);
		$emojiBtn.attr('aria-expanded', show ? 'true' : 'false');
	}

	function insertAtCursor(text) {
		var el = $input[0];
		if (!el) {
			return;
		}
		var value = $input.val();
		var start = (typeof el.selectionStart === 'number') ? el.selectionStart : value.length;
		var end = (typeof el.selectionEnd === 'number') ? el.selectionEnd : value.length;

		if (maxLength && (cpLength(value.slice(0, start)) + cpLength(text) + cpLength(value.slice(end))) > maxLength) {
			return;
		}

		$input.val(value.slice(0, start) + text + value.slice(end));
		var caret = start + text.length;
		if (el.setSelectionRange) {
			el.setSelectionRange(caret, caret);
		}
		updateCounter();
	}

	// Helpers
	function escapeHtml(text) {
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(text == null ? '' : String(text)));
		return div.innerHTML;
	}

	function escapeAttr(text) {
		return escapeHtml(text).replace(/"/g, '&quot;');
	}

	function isNearBottom() {
		var el = $messages[0];
		return (el.scrollHeight - el.scrollTop - el.clientHeight) < 60;
	}

	function isNearTop() {
		return $messages[0].scrollTop < 60;
	}

	// "Near the edge where the newest message lives" — bottom in default mode,
	// top in top-mode.
	function isNearEdge() {
		return topMode ? isNearTop() : isNearBottom();
	}

	function scrollToBottom() {
		var el = $messages[0];
		el.scrollTop = el.scrollHeight;
	}

	function scrollToTop() {
		$messages[0].scrollTop = 0;
	}

	// Scroll to wherever the newest message is.
	function scrollToEdge() {
		if (topMode) {
			scrollToTop();
		} else {
			scrollToBottom();
		}
	}

	function updateCounter() {
		if (!$counter.length) {
			return;
		}
		var len = cpLength($input.val());
		$counter.text(maxLength - len);
		$counter.toggleClass('stoker-chat-counter-warn', len > maxLength * 0.9);
	}

	function showError(msg) {
		phpbb.alert('', msg || errorText);
	}

	// Addons
	// Run addon code isolated, so one broken addon cannot break the chat.
	function runAddonCallback(fn, args) {
		try {
			return fn.apply(null, args);
		} catch (e) {
			if (window.console && window.console.error) {
				window.console.error(e);
			}
		}
		return undefined;
	}

	// Register a per-message menu action. Applies to messages rendered after registration.
	// action: { id, icon (Font Awesome class), label, isVisible(msg) optional, onClick(messageId, $msg) }
	function registerAction(action) {
		if (!action || typeof action.id !== 'string' || action.id === '' || typeof action.onClick !== 'function') {
			return false;
		}
		for (var i = 0; i < addonActions.length; i++) {
			if (addonActions[i].id === action.id) {
				return false;
			}
		}
		var label = String(action.label || '');
		addonActions.push({
			id: action.id,
			isVisible: typeof action.isVisible === 'function' ? action.isVisible : null,
			onClick: action.onClick,
			// Escaped once here rather than per rendered message
			escId: escapeAttr(action.id),
			escIcon: escapeAttr(action.icon || 'fa-puzzle-piece'),
			escLabel: escapeAttr(label)
		});
		return true;
	}

	function findAction(id) {
		for (var i = 0; i < addonActions.length; i++) {
			if (addonActions[i].id === id) {
				return addonActions[i];
			}
		}
		return null;
	}

	function buildAddonActions(msg) {
		var html = '';
		for (var i = 0; i < addonActions.length; i++) {
			var action = addonActions[i];
			if (action.isVisible && !runAddonCallback(action.isVisible, [msg])) {
				continue;
			}
			html += '<button type="button" class="stoker-chat-menu-item stoker-chat-addon-btn" data-id="' + msg.message_id + '" data-action="' + action.escId + '" title="' + action.escLabel + '" aria-label="' + action.escLabel + '"><i class="fa ' + action.escIcon + ' fa-fw" aria-hidden="true"></i></button>';
		}
		return html;
	}

	// Rendering
	function buildMessage(msg) {
		var avatar = msg.avatar || '';

		var colour = msg.user_colour ? escapeAttr(msg.user_colour) : '';
		var colourStyle = colour ? ' style="color: #' + colour + ';"' : '';

		// Quote and like both post a [quote], so neither is offered while that BBCode is disabled.
		var canQuote = msg.can_quote && !isBbcodeDisabled('quote');
		var canLike = msg.can_like && !isBbcodeDisabled('quote');

		var items = '';
		if (canQuote) {
			items += '<button type="button" class="stoker-chat-menu-item stoker-chat-quote-btn" data-id="' + msg.message_id + '" title="' + escapeAttr(quoteLabel) + '" aria-label="' + escapeAttr(quoteLabel) + '"><i class="fa fa-quote-left fa-fw" aria-hidden="true"></i></button>';
		}
		if (canLike) {
			items += '<button type="button" class="stoker-chat-menu-item stoker-chat-like-btn" data-id="' + msg.message_id + '" title="' + escapeAttr(likeLabel) + '" aria-label="' + escapeAttr(likeLabel) + '"><i class="fa fa-thumbs-up fa-fw" aria-hidden="true"></i></button>';
		}
		if (msg.can_edit) {
			items += '<button type="button" class="stoker-chat-menu-item stoker-chat-edit-btn" data-id="' + msg.message_id + '" title="' + escapeAttr(editLabel) + '" aria-label="' + escapeAttr(editLabel) + '"><i class="fa fa-pencil fa-fw" aria-hidden="true"></i></button>';
		}
		if (msg.can_delete) {
			items += '<button type="button" class="stoker-chat-menu-item stoker-chat-delete-btn" data-id="' + msg.message_id + '" title="' + escapeAttr(deleteLabel) + '" aria-label="' + escapeAttr(deleteLabel) + '"><i class="fa fa-trash fa-fw" aria-hidden="true"></i></button>';
		}
		if (addonActions.length) {
			items += buildAddonActions(msg);
		}

		var menu = '';
		if (items !== '') {
			menu = '<span class="stoker-chat-actions">' +
				'<span class="stoker-chat-menu">' + items + '</span>' +
				'<button type="button" class="stoker-chat-menu-toggle" data-id="' + msg.message_id + '" title="' + escapeAttr(menuLabel) + '" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bars fa-fw" aria-hidden="true"></i></button>' +
			'</span>';
		}

		var editedMark = msg.edit_time > 0
			? ' <span class="stoker-chat-edited" title="' + escapeAttr(editedLabel) + '">(' + escapeAttr(editedLabel) + ')</span>'
			: '';

		var html = '<div class="stoker-chat-msg" data-id="' + msg.message_id + '" data-raw="' + escapeAttr(msg.raw || '') + '">';
		html += '<div class="stoker-chat-avatar">' + avatar + '</div>';
		html += '<div class="stoker-chat-body">';
		html += '<div class="stoker-chat-meta">';
		html += '<a href="#" class="stoker-chat-user" data-username="' + escapeAttr(msg.username) + '" data-colour="' + colour + '"' + colourStyle + '>' + escapeHtml(msg.username) + '</a>';
		html += '<span class="stoker-chat-time">' + msg.time_format + '</span>';
		html += editedMark;
		if (menu) {
			html += menu;
		}
		html += '</div>';
		html += '<div class="stoker-chat-text">' + msg.message + '</div>';
		html += '</div></div>';
		return html;
	}

	// The server always returns batches in ascending (oldest-first) order. In
	// default mode that maps straight to top->bottom = oldest->newest. In top-mode
	// the visual order is reversed (top->bottom = newest->oldest), so the batch is
	// emitted in reverse. Callers then append (default) or prepend (top-mode).
	function buildBatch(list) {
		var html = '';
		var i;
		if (topMode) {
			for (i = list.length - 1; i >= 0; i--) {
				html += buildMessage(list[i]);
			}
		} else {
			for (i = 0; i < list.length; i++) {
				html += buildMessage(list[i]);
			}
		}
		return html;
	}

	function renderEmpty() {
		$messages.find('.stoker-chat-msg').remove();
		if (!$messages.find('.stoker-chat-empty').length) {
			$messages.append('<div class="stoker-chat-empty">' + escapeHtml(noMessages) + '</div>');
		}
	}

	// Shown when a load fails or returns a malformed response. Reuses the
	// empty-state layout but carries a distinct class and the error text, so a failed
	// load is not mistaken for a genuinely empty chat. Cleared on the next good load.
	// Placed at the newest edge so it is visible when messages are already shown.
	function renderLoadError(text) {
		$messages.find('.stoker-chat-empty, .stoker-chat-error').remove();
		var html = '<div class="stoker-chat-empty stoker-chat-error">' + escapeHtml(text || errorText) + '</div>';
		if (topMode) {
			$messages.prepend(html);
		} else {
			$messages.append(html);
		}
	}

	// Polling
	function renderLoadOlder() {
		// No-op if already rendered
		if ($messages.find('.stoker-chat-load-older').length) {
			return;
		}
		var html = '<div class="stoker-chat-load-older">' +
			'<a href="#" class="stoker-chat-load-older-link">' + escapeHtml(loadOlderLabel) + '</a>' +
			'</div>';
		if (topMode) {
			// Older messages live at the bottom in top-mode.
			$messages.append(html);
		} else {
			$messages.prepend(html);
		}
	}

	function removeLoadOlder() {
		$messages.find('.stoker-chat-load-older').remove();
	}

	function pruneMessages() {
		if (maxMessages <= 0) {
			return;
		}
		var $msgs = $messages.find('.stoker-chat-msg');
		var excess = $msgs.length - maxMessages;
		if (excess <= 0) {
			return;
		}
		if (topMode) {
			// Oldest rows are at the bottom in top-mode.
			$msgs.slice(-excess).remove();
		} else {
			$msgs.slice(0, excess).remove();
		}
		// The pruned rows still exist server-side — offer them via "load older".
		hasMore = true;
		renderLoadOlder();
	}

	// More new messages arrived than the chat displays (e.g. after a lockdown): the
	// server sent only the newest batch, so replace every rendered row with it. Older
	// messages stay reachable through "load older".
	function renderGap(list) {
		$messages.find('.stoker-chat-msg, .stoker-chat-empty, .stoker-chat-error').remove();
		removeLoadOlder();
		for (var i = 0; i < list.length; i++) {
			if (list[i].message_id > lastId) {
				lastId = list[i].message_id;
			}
		}
		$messages.append(buildBatch(list));
		var $rows = $messages.find('.stoker-chat-msg');
		wrapEmoji($rows.find('.stoker-chat-text'));
		$chat.trigger('stoker_chat_messages_rendered', [$rows, 'new']);
		hasMore = true;
		renderLoadOlder();
		scrollToEdge();
	}

	function oldestVisibleId() {
		var $msgs = $messages.find('.stoker-chat-msg');
		var $oldest = topMode ? $msgs.last() : $msgs.first();
		if (!$oldest.length) {
			return 0;
		}
		return parseInt($oldest.data('id'), 10) || 0;
	}

	function applyEdit(msg) {
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + msg.message_id + '"]');
		if (!$msg.length) {
			return;
		}
		// The viewer is editing this message: hold the remote edit until edit mode
		// ends, otherwise it is lost because lastCheck has already moved past it.
		if ($msg.hasClass('editing')) {
			$msg.data('pending-edit', msg);
			return;
		}
		$msg.attr('data-raw', msg.raw || '');
		var $text = $msg.find('.stoker-chat-text');
		$text.html(msg.message);
		wrapEmoji($text);

		if (msg.edit_time > 0) {
			var $meta = $msg.find('.stoker-chat-meta');
			if (!$meta.find('.stoker-chat-edited').length) {
				$meta.find('.stoker-chat-time').after(' <span class="stoker-chat-edited" title="' + escapeAttr(editedLabel) + '">(' + escapeAttr(editedLabel) + ')</span>');
			}
		}

		$chat.trigger('stoker_chat_message_updated', [$msg, msg]);
	}

	function applyDelete(messageId) {
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + messageId + '"]');
		if (!$msg.length) {
			return;
		}
		$msg.fadeOut(200, function() {
			$(this).remove();
			if ($messages.find('.stoker-chat-msg').length === 0) {
				renderEmpty();
			}
		});
	}

	// The server refused the request (permission revoked, logged out elsewhere):
	// stop polling for good and show why. Only a page reload resumes the chat.
	function haltPolling(text) {
		isHalted = true;
		stopPolling();
		renderLoadError(text);
	}

	// Fetch right after the user's own post. A poll already in flight may have read
	// the table before the insert, so queue one more fetch to run when it finishes.
	function refreshNow() {
		if (isBusy) {
			refreshQueued = true;
			return;
		}
		fetchMessages();
	}

	function flushQueuedRefresh() {
		if (refreshQueued) {
			refreshQueued = false;
			fetchMessages();
		}
	}

	function loadInitial() {
		if (isHalted || isBusy) {
			return;
		}
		// Collapsed via Collapsible Categories: skip the request but keep the poll
		// timer running, so the first poll after expanding performs the initial load.
		if ($messages.is(':hidden')) {
			if (!pollTimer) {
				startPolling();
			}
			return;
		}
		isBusy = true;

		$.ajax({
			url: fetchUrl,
			data: {},
			dataType: 'json'
		}).done(function(data) {
			if (data && data.success === false) {
				haltPolling(data.error);
				return;
			}

			if (!data || !data.messages) {
				renderLoadError();
				return;
			}

			if (data.now) {
				lastCheck = data.now;
			}

			$messages.find('.stoker-chat-empty, .stoker-chat-error').remove();

			if (data.messages.length === 0) {
				renderEmpty();
				hasMore = false;
			} else {
				for (var i = 0; i < data.messages.length; i++) {
					if (data.messages[i].message_id > lastId) {
						lastId = data.messages[i].message_id;
					}
				}
				$messages.append(buildBatch(data.messages));
				var $rows = $messages.find('.stoker-chat-msg');
				wrapEmoji($rows.find('.stoker-chat-text'));
				$chat.trigger('stoker_chat_messages_rendered', [$rows, 'initial']);
				scrollToEdge();
				hasMore = !!data.has_more;
				if (hasMore) {
					renderLoadOlder();
				}
			}

			$chat.trigger('stoker_chat_poll_done', [data, 'initial']);
		}).fail(function() {
			renderLoadError();
		}).always(function() {
			isBusy = false;
			if (!pollTimer) {
				startPolling();
			}
			flushQueuedRefresh();
		});
	}

	function fetchMessages() {
		if (isHalted || isBusy) {
			return;
		}
		// Collapsed via Collapsible Categories (or otherwise not rendered): skip this
		// poll. The next poll after the chat is expanded catches up via the delta.
		if ($messages.is(':hidden')) {
			return;
		}
		if (lastId === 0) {
			// Chat is still empty — re-run the initial load so other users'
			// first messages appear without a reload or visibility change.
			loadInitial();
			return;
		}
		isBusy = true;

		var params = { last_id: lastId };
		if (lastCheck > 0) {
			params.last_check = lastCheck;
			var oldest = oldestVisibleId();
			if (oldest > 0) {
				params.oldest_visible_id = oldest;
			}
		}

		$.ajax({
			url: fetchUrl,
			data: params,
			dataType: 'json'
		}).done(function(data) {
			if (!data) {
				return;
			}

			if (data.success === false) {
				haltPolling(data.error);
				return;
			}

			if (data.now) {
				lastCheck = data.now;
			}

			// Gap: the rendered rows are replaced, so edits and deletions for them do not apply
			if (data.gap && data.messages && data.messages.length) {
				renderGap(data.messages);
				forceScrollOnNext = false;
				$chat.trigger('stoker_chat_poll_done', [data, 'delta']);
				return;
			}

			// Apply deletions first so subsequent edits don't target removed nodes
			if (data.deleted && data.deleted.length) {
				for (var d = 0; d < data.deleted.length; d++) {
					applyDelete(data.deleted[d]);
				}
			}

			// Apply edits to existing messages
			if (data.edited && data.edited.length) {
				for (var e = 0; e < data.edited.length; e++) {
					applyEdit(data.edited[e]);
				}
			}

			// Insert new messages at the newest edge
			if (data.messages && data.messages.length > 0) {
				$messages.find('.stoker-chat-empty, .stoker-chat-error').remove();

				var wasAtEdge = isNearEdge();
				var addedCount = data.messages.length;
				for (var i = 0; i < data.messages.length; i++) {
					if (data.messages[i].message_id > lastId) {
						lastId = data.messages[i].message_id;
					}
				}
				var html = buildBatch(data.messages);
				var el = $messages[0];

				if (topMode) {
					// Newest goes on top, pushing older content down.
					var prevHeight = el.scrollHeight;
					$messages.prepend(html);
					var $newTop = $messages.find('.stoker-chat-msg').slice(0, addedCount);
					wrapEmoji($newTop.find('.stoker-chat-text'));
					$chat.trigger('stoker_chat_messages_rendered', [$newTop, 'new']);

					if (wasAtEdge) {
						pruneMessages();
						scrollToTop();
					} else {
						// User is reading older messages further down: hold their
						// position by absorbing the height the prepend just added.
						el.scrollTop += (el.scrollHeight - prevHeight);
					}
				} else {
					var existingCount = $messages.find('.stoker-chat-msg').length;
					$messages.append(html);
					var $newBottom = $messages.find('.stoker-chat-msg').slice(existingCount);
					wrapEmoji($newBottom.find('.stoker-chat-text'));
					$chat.trigger('stoker_chat_messages_rendered', [$newBottom, 'new']);

					if (wasAtEdge) {
						pruneMessages();
						scrollToBottom();
					}
				}
			}

			// Honour the force-scroll request even if no new messages came
			// back this round — the message may already have been pulled in
			// by a regular poll that fired between POST and this fetch.
			if (forceScrollOnNext) {
				scrollToEdge();
				forceScrollOnNext = false;
			}

			$chat.trigger('stoker_chat_poll_done', [data, 'delta']);
		}).always(function() {
			isBusy = false;
			flushQueuedRefresh();
		});
	}

	function loadOlder() {
		if (isLoadingOlder || !hasMore) {
			return;
		}
		var $msgs = $messages.find('.stoker-chat-msg');
		if (!$msgs.length) {
			return;
		}
		// The oldest visible row sits at the top in default mode, at the bottom in top-mode.
		var $oldestMsg = topMode ? $msgs.last() : $msgs.first();
		var oldestId = parseInt($oldestMsg.data('id'), 10);
		if (!oldestId) {
			return;
		}

		isLoadingOlder = true;
		var $link = $messages.find('.stoker-chat-load-older-link');
		var originalText = $link.text();
		$link.text(loadOlderLoading).addClass('stoker-chat-load-older-busy');

		// Capture scroll anchor: position of the oldest message before inserting
		var el = $messages[0];
		var anchorOffsetBefore = $oldestMsg[0].offsetTop - el.scrollTop;

		$.ajax({
			url: fetchUrl,
			data: { before_id: oldestId },
			dataType: 'json'
		}).done(function(data) {
			if (!data || !data.messages || data.messages.length === 0) {
				hasMore = false;
				removeLoadOlder();
				return;
			}

			// Deliberately do not advance lastCheck here: this response carries no
			// edited/deleted data, so moving the watermark would skip those events.

			var html = buildBatch(data.messages);

			var $loadLink = $messages.find('.stoker-chat-load-older');
			if ($loadLink.length) {
				// Older rows go between the existing messages and the load-older link.
				if (topMode) {
					$loadLink.before(html);
				} else {
					$loadLink.after(html);
				}
			} else if (topMode) {
				$messages.append(html);
			} else {
				$messages.prepend(html);
			}

			// The just-inserted messages are those older than the previously-oldest id.
			var $older = $messages.find('.stoker-chat-msg').filter(function() {
				var thisId = parseInt($(this).data('id'), 10);
				return thisId && thisId < oldestId;
			});
			wrapEmoji($older.find('.stoker-chat-text'));
			$chat.trigger('stoker_chat_messages_rendered', [$older, 'older']);

			hasMore = !!data.has_more;
			if (!hasMore) {
				removeLoadOlder();
			}

			// Restore scroll: the previously-oldest message should sit at the same offset it was at
			var $newOldest = $messages.find('.stoker-chat-msg[data-id="' + oldestId + '"]');
			if ($newOldest.length) {
				el.scrollTop = $newOldest[0].offsetTop - anchorOffsetBefore;
			}

			$chat.trigger('stoker_chat_poll_done', [data, 'older']);
		}).fail(function() {
			showError();
		}).always(function() {
			isLoadingOlder = false;
			$messages.find('.stoker-chat-load-older-link')
				.text(originalText)
				.removeClass('stoker-chat-load-older-busy');
		});
	}

	function startPolling() {
		stopPolling();
		// Fix B: do not poll when tab is hidden, chat is locked or polling was halted
		if (!isVisible || isLocked || isHalted) {
			return;
		}
		pollTimer = setInterval(fetchMessages, pollInterval);
	}

	function stopPolling() {
		if (pollTimer) {
			clearInterval(pollTimer);
			pollTimer = null;
		}
	}

	// Inactivity lockdown
	function noteActivity() {
		if (inactivityMs <= 0) {
			return;
		}
		// Throttle to at most once per second
		var now = Date.now();
		if (now - lastActivityReset < 1000) {
			return;
		}
		lastActivityReset = now;
		lastActivity = now;
		if (isLocked) {
			return;
		}
		scheduleInactivityCheck();
	}

	function scheduleInactivityCheck() {
		if (inactivityMs <= 0) {
			return;
		}
		if (inactivityTimer) {
			clearTimeout(inactivityTimer);
		}
		var delay = Math.max(1000, (lastActivity + inactivityMs) - Date.now());
		inactivityTimer = setTimeout(checkInactivity, delay);
	}

	function checkInactivity() {
		inactivityTimer = null;
		if (isLocked || inactivityMs <= 0) {
			return;
		}
		var idle = Date.now() - lastActivity;
		if (idle >= inactivityMs) {
			lockChat();
		} else {
			scheduleInactivityCheck();
		}
	}

	function lockChat() {
		if (isLocked) {
			return;
		}
		isLocked = true;
		stopPolling();
		if (inactivityTimer) {
			clearTimeout(inactivityTimer);
			inactivityTimer = null;
		}
		$input.prop('disabled', true);
		$send.prop('disabled', true);
		$lockdown.removeAttr('hidden');
	}

	function unlockChat() {
		if (!isLocked) {
			return;
		}
		isLocked = false;
		$lockdown.attr('hidden', 'hidden');
		$input.prop('disabled', false);
		$send.prop('disabled', false);
		lastActivity = Date.now();
		lastActivityReset = lastActivity;
		// Catch up + resume polling
		if (lastId === 0) {
			loadInitial();
		} else {
			fetchMessages();
			startPolling();
		}
		scheduleInactivityCheck();
	}

	// Send
	function sendMessage() {
		var text = $.trim($input.val());
		if (text === '') {
			return;
		}
		// Addons may rewrite the text or cancel the send (e.g. a client-side command)
		var send = { text: text, cancel: false };
		$chat.trigger('stoker_chat_before_send', [send, 'post', 0]);
		if (send.cancel) {
			return;
		}
		text = $.trim(String(send.text));
		if (text === '') {
			return;
		}
		text = convertEmoticons(text);
		if (cpLength(text) > maxLength) {
			showError(tooLongText);
			return;
		}

		$send.prop('disabled', true);
		$input.prop('disabled', true);

		$.ajax({
			url: postUrl,
			method: 'POST',
			data: { message: text, hash: chatHash },
			dataType: 'json'
		}).done(function(data) {
			if (data && data.success) {
				$input.val('');
				updateCounter();
				forceScrollOnNext = true;
				refreshNow();
			} else {
				showError(data && data.error ? data.error : null);
			}
		}).fail(function(jqXHR) {
			var msg = null;
			try {
				var data = JSON.parse(jqXHR.responseText);
				if (data && data.error) { msg = data.error; }
			} catch (e) { /* non-JSON response */ }
			showError(msg);
		}).always(function() {
			$send.prop('disabled', false);
			$input.prop('disabled', false);
			$input.trigger('focus');
		});
	}

	// Edit
	function enterEditMode(messageId) {
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + messageId + '"]');
		if (!$msg.length || $msg.hasClass('editing')) {
			return;
		}

		var $text = $msg.find('.stoker-chat-text');
		var editable = $msg.attr('data-raw') || '';

		// maxlength counts UTF-16 units; the code-point limit is enforced in saveEdit() and on the server.
		var inputId = 'stoker-chat-edit-' + messageId;
		var editHtml =
			'<div class="stoker-chat-edit-box">' +
				'<input type="text" id="' + inputId + '" class="stoker-chat-edit-input" maxlength="' + (maxLength * 2) + '" value="' + escapeAttr(editable) + '">' +
				'<button type="button" class="stoker-chat-edit-save" data-id="' + messageId + '">' + escapeHtml(editSave) + '</button>' +
				'<button type="button" class="stoker-chat-edit-cancel" data-id="' + messageId + '">' + escapeHtml(editCancel) + '</button>' +
			'</div>';

		$text.hide().after(editHtml);
		$msg.addClass('editing');
		$msg.find('.stoker-chat-edit-input').trigger('focus');
	}

	function exitEditMode(messageId, newHtml, editTime, newRaw) {
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + messageId + '"]');
		if (!$msg.length) {
			return;
		}
		var $text = $msg.find('.stoker-chat-text');
		var pending = $msg.data('pending-edit');
		$msg.removeData('pending-edit');

		if (newHtml !== undefined) {
			// Own save: the server response is newer than any held remote edit.
			pending = null;
			$text.html(newHtml);
			wrapEmoji($text);
			if (newRaw !== undefined) {
				$msg.attr('data-raw', newRaw);
			}
			if (editTime > 0) {
				var $meta = $msg.find('.stoker-chat-meta');
				if (!$meta.find('.stoker-chat-edited').length) {
					$meta.find('.stoker-chat-time').after(' <span class="stoker-chat-edited" title="' + escapeAttr(editedLabel) + '">(' + escapeAttr(editedLabel) + ')</span>');
				}
			}
		}

		$msg.find('.stoker-chat-edit-box').remove();
		$text.show();
		$msg.removeClass('editing');

		if (newHtml !== undefined) {
			$chat.trigger('stoker_chat_message_updated', [$msg, null]);
		}

		// Cancelled: apply a remote edit that arrived while editing.
		if (pending) {
			applyEdit(pending);
		}
	}

	function saveEdit(messageId) {
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + messageId + '"]');
		var $input = $msg.find('.stoker-chat-edit-input');
		var text = $.trim($input.val());

		if (text === '') {
			showError();
			return;
		}
		var send = { text: text, cancel: false };
		$chat.trigger('stoker_chat_before_send', [send, 'edit', messageId]);
		if (send.cancel) {
			return;
		}
		text = $.trim(String(send.text));
		if (text === '') {
			showError();
			return;
		}
		text = convertEmoticons(text);
		if (cpLength(text) > maxLength) {
			showError(tooLongText);
			return;
		}

		$input.prop('disabled', true);
		$msg.find('.stoker-chat-edit-save, .stoker-chat-edit-cancel').prop('disabled', true);

		$.ajax({
			url: editUrl,
			method: 'POST',
			data: { message_id: messageId, message: text, hash: chatHash },
			dataType: 'json'
		}).done(function(data) {
			if (data && data.success) {
				exitEditMode(messageId, data.message, data.edit_time, data.raw);
			} else {
				showError(data && data.error ? data.error : null);
				$input.prop('disabled', false);
				$msg.find('.stoker-chat-edit-save, .stoker-chat-edit-cancel').prop('disabled', false);
			}
		}).fail(function(jqXHR) {
			var msg = null;
			try {
				var data = JSON.parse(jqXHR.responseText);
				if (data && data.error) { msg = data.error; }
			} catch (e) { /* non-JSON response */ }
			showError(msg);
			$input.prop('disabled', false);
			$msg.find('.stoker-chat-edit-save, .stoker-chat-edit-cancel').prop('disabled', false);
		});
	}

	// Delete
	function deleteMessage(messageId) {
		$.ajax({
			url: deleteUrl,
			method: 'POST',
			data: { message_id: messageId, hash: chatHash },
			dataType: 'json'
		}).done(function(data) {
			if (data && data.success) {
				$messages.find('.stoker-chat-msg[data-id="' + messageId + '"]').fadeOut(200, function() {
					$(this).remove();
					if ($messages.find('.stoker-chat-msg').length === 0) {
						renderEmpty();
					}
				});
			} else {
				showError(data && data.error ? data.error : null);
			}
		}).fail(function(jqXHR) {
			var msg = null;
			try {
				var data = JSON.parse(jqXHR.responseText);
				if (data && data.error) { msg = data.error; }
			} catch (e) { /* non-JSON response */ }
			showError(msg);
		});
	}

	// Quote
	function buildQuoteString(messageId) {
		if (isBbcodeDisabled('quote')) {
			return '';
		}
		var $msg = $messages.find('.stoker-chat-msg[data-id="' + messageId + '"]');
		if (!$msg.length) {
			return '';
		}
		var $text = $msg.find('.stoker-chat-text');
		if (!$text.length) {
			return '';
		}
		var username = String($msg.find('.stoker-chat-user').data('username') || '').replace(/[\[\]]/g, '');
		var $clone = $text.clone();
		// Strip nested quotes, including their "<user> wrote:" cite
		$clone.find('blockquote, quote, .quotetitle, .quotecontent, .quote-author, [class*="quote"]').remove();
		var body = $clone[0].textContent.replace(/\s+/g, ' ').trim();
		if (body === '') {
			return '';
		}
		var chars = Array.from(body);
		if (chars.length > 40) {
			body = chars.slice(0, 40).join('') + '…';
		}
		// Neutralise "[" with a zero-width space so quoted text cannot open a BBCode tag
		body = body.replace(/\[/g, '[​');
		var open = username ? '[quote=' + username + ']' : '[quote]';
		return open + body + '[/quote] ';
	}

	function quoteMessage(messageId) {
		if ($input.prop('disabled')) {
			return;
		}
		var quote = buildQuoteString(messageId);
		if (quote === '') {
			return;
		}
		var current = $input.val();
		if (current.length > 0 && !/\s$/.test(current)) {
			current += ' ';
		}
		$input.val(current + quote);
		updateCounter();
		$input.trigger('focus');
		// Cursor at end so the user types their reply right after the quote
		var len = $input.val().length;
		$input[0].setSelectionRange(len, len);
	}

	// Like
	function likeMessage(messageId) {
		var quote = buildQuoteString(messageId);
		if (quote === '') {
			return;
		}
		var text = quote + '👍';

		$.ajax({
			url: postUrl,
			method: 'POST',
			data: { message: text, hash: chatHash },
			dataType: 'json'
		}).done(function(data) {
			if (data && data.success) {
				forceScrollOnNext = true;
				refreshNow();
			} else {
				showError(data && data.error ? data.error : null);
			}
		}).fail(function(jqXHR) {
			var msg = null;
			try {
				var data = JSON.parse(jqXHR.responseText);
				if (data && data.error) { msg = data.error; }
			} catch (e) { /* non-JSON response */ }
			showError(msg);
		});
	}

	// Event wiring
	$(document).on('visibilitychange', function() {
		isVisible = !document.hidden;
		if (!isVisible) {
			stopPolling();
			if (tabHiddenMs <= 0) {
				return;
			}
			if (hideLockTimer) {
				clearTimeout(hideLockTimer);
			}
			hideLockTimer = setTimeout(function() {
				hideLockTimer = null;
				if (!isVisible) {
					lockChat();
				}
			}, tabHiddenMs);
			return;
		}

		// Tab visible — cancel any pending lock from a brief tab switch.
		if (hideLockTimer) {
			clearTimeout(hideLockTimer);
			hideLockTimer = null;
		}

		if (isLocked) {
			// Lock fired before the user came back: stay locked until click.
			return;
		}

		// Came back within the grace window: resume normally.
		if (lastId === 0) {
			loadInitial();
		} else {
			fetchMessages();
			startPolling();
		}
	});

	$send.on('click', function(e) {
		e.preventDefault();
		sendMessage();
	});

	$input.on('keydown', function(e) {
		// Enter that confirms an IME composition (CJK input) must not send
		if (e.isComposing || e.keyCode === 229) {
			return;
		}
		if (e.key === 'Enter' || e.keyCode === 13) {
			e.preventDefault();
			sendMessage();
		}
	});

	$input.on('input', updateCounter);

	$emojiBtn.on('click', function(e) {
		e.preventDefault();
		e.stopPropagation();
		if ($input.prop('disabled')) {
			return;
		}
		toggleEmojiPicker();
		if (!$emojiPicker.prop('hidden')) {
			$input.trigger('focus');
		}
	});

	$emojiPicker.on('click', '.stoker-chat-emoji-choice', function(e) {
		e.preventDefault();
		insertAtCursor($(this).text());
		$input.trigger('focus');
	});

	$emojiPicker.on('click', function(e) {
		e.stopPropagation();
	});

	$(document).on('click', function() {
		toggleEmojiPicker(false);
	});

	$input.on('keydown', function(e) {
		if (e.key === 'Escape' || e.keyCode === 27) {
			toggleEmojiPicker(false);
		}
	});

	$messages.on('click', '.stoker-chat-load-older-link', function(e) {
		e.preventDefault();
		loadOlder();
	});

	$messages.on('click', '.stoker-chat-user', function(e) {
		e.preventDefault();
		if ($input.prop('disabled')) {
			return;
		}
		var username = String($(this).data('username') || '').replace(/[\[\]]/g, '');
		var colour   = $(this).data('colour') || '';
		if (username === '') {
			return;
		}

		// Only wrap the name in BBCodes the chat allows
		var bbcode = username;
		if (colour && !isBbcodeDisabled('color')) {
			bbcode = '[color=#' + colour + ']' + bbcode + '[/color]';
		}
		if (!isBbcodeDisabled('b')) {
			bbcode = '[b]' + bbcode + '[/b]';
		}
		bbcode += ' ';

		var current = $input.val();
		if (current.length > 0 && !/\s$/.test(current)) {
			current += ' ';
		}
		$input.val(current + bbcode);
		updateCounter();
		$input.trigger('focus');
	});

	function closeAllMenus() {
		$messages.find('.stoker-chat-actions.open').removeClass('open');
		$messages.find('.stoker-chat-menu-toggle[aria-expanded="true"]').attr('aria-expanded', 'false');
	}

	$messages.on('click', '.stoker-chat-menu-toggle', function(e) {
		e.preventDefault();
		e.stopPropagation();
		var $btn = $(this);
		var $actions = $btn.closest('.stoker-chat-actions');
		var wasOpen = $actions.hasClass('open');
		closeAllMenus();
		if (!wasOpen) {
			$actions.addClass('open');
			$btn.attr('aria-expanded', 'true');
		}
	});

	$(document).on('click', function() {
		closeAllMenus();
	});

	$messages.on('click', '.stoker-chat-menu', function(e) {
		e.stopPropagation();
	});

	$messages.on('click', '.stoker-chat-delete-btn', function(e) {
		e.preventDefault();
		closeAllMenus();
		var id = parseInt($(this).data('id'), 10);
		// phpbb.confirm() expects the Yes/No inputs inside the message HTML —
		// core normally gets them from the server-rendered confirm page.
		var confirmHtml = '<p>' + escapeHtml(deleteConfirm) + '</p>' +
			'<fieldset class="submit-buttons">' +
				'<input type="button" name="confirm" class="button1" value="' + escapeAttr(confirmYes) + '">' +
				'&nbsp;' +
				'<input type="button" name="cancel" class="button2" value="' + escapeAttr(confirmNo) + '">' +
			'</fieldset>';
		phpbb.confirm(confirmHtml, function(confirmed) {
			if (confirmed) {
				deleteMessage(id);
			}
		});
	});

	$messages.on('click', '.stoker-chat-quote-btn', function(e) {
		e.preventDefault();
		closeAllMenus();
		quoteMessage(parseInt($(this).data('id'), 10));
	});

	$messages.on('click', '.stoker-chat-like-btn', function(e) {
		e.preventDefault();
		closeAllMenus();
		likeMessage(parseInt($(this).data('id'), 10));
	});

	$messages.on('click', '.stoker-chat-addon-btn', function(e) {
		e.preventDefault();
		closeAllMenus();
		var action = findAction($(this).attr('data-action'));
		if (!action) {
			return;
		}
		runAddonCallback(action.onClick, [parseInt($(this).data('id'), 10), $(this).closest('.stoker-chat-msg')]);
	});

	$messages.on('click', '.stoker-chat-edit-btn', function(e) {
		e.preventDefault();
		closeAllMenus();
		enterEditMode(parseInt($(this).data('id'), 10));
	});

	$messages.on('click', '.stoker-chat-edit-save', function(e) {
		e.preventDefault();
		saveEdit(parseInt($(this).data('id'), 10));
	});

	$messages.on('click', '.stoker-chat-edit-cancel', function(e) {
		e.preventDefault();
		exitEditMode(parseInt($(this).data('id'), 10));
	});

	$messages.on('keydown', '.stoker-chat-edit-input', function(e) {
		// Enter/Escape inside an IME composition (CJK input) belong to the IME
		if (e.isComposing || e.keyCode === 229) {
			return;
		}
		if (e.key === 'Enter' || e.keyCode === 13) {
			e.preventDefault();
			var id = parseInt($(this).closest('.stoker-chat-msg').data('id'), 10);
			saveEdit(id);
		} else if (e.key === 'Escape' || e.keyCode === 27) {
			e.preventDefault();
			var id2 = parseInt($(this).closest('.stoker-chat-msg').data('id'), 10);
			exitEditMode(id2);
		}
	});

	// Initialise
	$lockdown.on('click', function(e) {
		e.preventDefault();
		unlockChat();
	});
	$lockdown.on('keydown', function(e) {
		if (e.key === ' ' || e.key === 'Enter' || e.keyCode === 13 || e.keyCode === 32) {
			e.preventDefault();
			unlockChat();
		}
	});

	if (inactivityMs > 0) {
		// Activity tracking (page-wide). Throttled inside noteActivity().
		$(document).on('mousemove keydown click touchstart', noteActivity);
		document.addEventListener('scroll', noteActivity, { passive: true, capture: true });

		scheduleInactivityCheck();
	}

	// Addon API. Addons queue a callback, which works whether their script loads
	// before or after this file:
	//   window.stokerChatAddons = window.stokerChatAddons || [];
	//   window.stokerChatAddons.push(function(api) { ... });
	var api = {
		chat: $chat,
		input: $input,
		hash: chatHash,
		canPost: $input.length > 0,
		escapeHtml: escapeHtml,
		escapeAttr: escapeAttr,
		insertAtCursor: insertAtCursor,
		isBbcodeDisabled: isBbcodeDisabled,
		refresh: refreshNow,
		registerAction: registerAction
	};

	var queuedAddons = window.stokerChatAddons;
	window.stokerChatAddons = {
		push: function(fn) {
			if (typeof fn === 'function') {
				runAddonCallback(fn, [api]);
			}
		}
	};
	if (Array.isArray(queuedAddons)) {
		for (var q = 0; q < queuedAddons.length; q++) {
			window.stokerChatAddons.push(queuedAddons[q]);
		}
	}

	$chat.trigger('stoker_chat_ready', [api]);

	buildEmojiPicker();
	updateCounter();

	loadInitial();

})(jQuery);
