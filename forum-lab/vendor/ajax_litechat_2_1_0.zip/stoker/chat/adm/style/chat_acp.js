(function($) {
	'use strict';

	function toggleSwitch($toggle) {
		if ($toggle.hasClass('ajax-busy')) {
			return;
		}
		$toggle.addClass('ajax-busy');
		var url = $toggle.data('toggle-url');
		var $indicator = phpbb.loadingIndicator();
		$.get(url, function(res) {
			if (res && res.success) {
				var checkbox = $toggle.find('input[type="checkbox"]')[0];
				if (checkbox) {
					checkbox.checked = !checkbox.checked;
					// A toggle is saved instantly, a form reset must not revert it
					checkbox.defaultChecked = checkbox.checked;
					$toggle.attr('aria-checked', checkbox.checked);
				}
			} else {
				// phpBB answers a server-side trigger_error() on AJAX with HTTP 200 JSON
				phpbb.alert('', (res && res.MESSAGE_TEXT) ? res.MESSAGE_TEXT : $toggle.data('toggle-error'));
			}
		}, 'json').fail(function() {
			phpbb.alert('', $toggle.data('toggle-error'));
		}).always(function() {
			$toggle.removeClass('ajax-busy');
			if ($indicator) {
				$indicator.fadeOut(100);
			}
		});
	}

	$(document).on('click', '.toggle-switch[data-toggle-url]', function(e) {
		e.preventDefault();
		toggleSwitch($(this));
	});

	$(document).on('keydown', '.toggle-switch[data-toggle-url]', function(e) {
		if (e.key === ' ' || e.key === 'Enter') {
			e.preventDefault();
			toggleSwitch($(this));
		}
	});

	// Emoji table: client-side add/remove rows; the whole table is saved on form submit.
	var $emojiTable = $('#stoker-chat-emoji-table');
	if ($emojiTable.length) {
		var $emojiRows = $('#stoker-chat-emoji-rows');
		var emojiTpl = document.getElementById('stoker-chat-emoji-row-tpl');
		var nextEmojiIndex = $emojiRows.children('tr').length;

		$('#stoker-chat-emoji-add').on('click', function() {
			if (!emojiTpl) {
				return;
			}
			var html = emojiTpl.innerHTML.replace(/__INDEX__/g, String(nextEmojiIndex));
			nextEmojiIndex++;
			var $row = $($.trim(html));
			$emojiRows.append($row);
			$row.find('.stoker-chat-emoji-char').trigger('focus');
		});

		$emojiRows.on('click', '.stoker-chat-emoji-del', function() {
			$(this).closest('tr').remove();
		});
	}
})(jQuery);