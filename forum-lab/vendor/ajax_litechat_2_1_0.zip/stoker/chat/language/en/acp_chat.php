<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, [
	// Header
	'ACP_STOKER_BADGE'							=> 'LiteChat',
	'ACP_STOKER_SETTINGS_EXPLAIN'				=> 'If you like this extension, please consider following',
	'ACP_STOKER_DONATION'						=> 'Make a Donation',
	'ACP_STOKER_MEMBER'							=> 'Become an active member of my Community',
	'ACP_STOKER_SUPPORT'						=> 'Extension support or feedback',
	'ACP_EC_REPORT'								=> 'phpBB Ext Check Report',

	// Toggle
	'ACP_STOKER_TOGGLE_ERROR'					=> 'The toggle request failed. Please try again.',

	// Settings
	'ACP_STOKER_CHAT_INDEX_ENABLE'				=> 'Display chat on forum index',
	'ACP_STOKER_CHAT_INDEX_ENABLE_EXPLAIN'		=> 'Show the chat widget on the forum index page.',
	'ACP_STOKER_CHAT_PORTAL_ENABLE'				=> 'Display chat on Portal',
	'ACP_STOKER_CHAT_PORTAL_ENABLE_EXPLAIN'		=> 'Show the chat widget on the portal page.',
	'ACP_STOKER_CHAT_PORTAL_NOT_AVAILABLE'		=> 'This option is only available if <a href="https://phpbb3bbcodes.com/viewtopic.php?t=2719" title="Visit Simple Portal topic at PhpBB3 BBCodes" target="_blank" rel="noopener noreferrer">Simple Portal</a> is installed and enabled!',
	'ACP_STOKER_CHAT_INDEX_POSITION'			=> 'Chat position on forum index',
	'ACP_STOKER_CHAT_INDEX_POSITION_EXPLAIN'	=> 'Where to display the chat widget relative to the forum list.',
	'ACP_STOKER_CHAT_INDEX_TOP'					=> 'Above the forum list',
	'ACP_STOKER_CHAT_INDEX_BOTTOM'				=> 'Below the forum list',
	'ACP_STOKER_CHAT_ACTION_BAR'				=> 'Message action bar',
	'ACP_STOKER_CHAT_ACTION_BAR_EXPLAIN'		=> 'How the per-message actions (quote, like, edit, delete) are presented.',
	'ACP_STOKER_CHAT_ACTION_BAR_RESPONSIVE'		=> 'Responsive - icons on desktop, menu on mobile',
	'ACP_STOKER_CHAT_ACTION_BAR_MENU'			=> 'Always a menu',
	'ACP_STOKER_CHAT_ACTION_BAR_ICONS'			=> 'Always icons - never a menu',
	'ACP_STOKER_CHAT_PORTAL_POSITION'			=> 'Chat position on Portal page',
	'ACP_STOKER_CHAT_PORTAL_POSITION_EXPLAIN'	=> 'Where to display the chat widget on the Portal page.',
	'ACP_STOKER_CHAT_PORTAL_TOP'				=> 'Top of the Portal',
	'ACP_STOKER_CHAT_PORTAL_MIDDLE'				=> 'Middle of the Portal',
	'ACP_STOKER_CHAT_PORTAL_BOTTOM'				=> 'Bottom of the Portal',
	'ACP_STOKER_CHAT_POLL_INTERVAL'				=> 'Poll interval',
	'ACP_STOKER_CHAT_POLL_INTERVAL_EXPLAIN'		=> 'How often the chat checks for new messages (in seconds).<br>Lower values feel more responsive but increase server load.',
	'ACP_STOKER_CHAT_FLOOD_INTERVAL'			=> 'Flood interval',
	'ACP_STOKER_CHAT_FLOOD_INTERVAL_EXPLAIN'	=> 'Minimum seconds between messages from the same user.<br>Set to 0 to disable. Users with the noflood permission bypass this limit.',
	'ACP_STOKER_CHAT_MAX_MESSAGES'				=> 'Maximum messages displayed',
	'ACP_STOKER_CHAT_MAX_MESSAGES_EXPLAIN'		=> 'Maximum number of messages to show in the chat window.',
	'ACP_STOKER_CHAT_INITIAL_LOAD'				=> 'Initial messages to load',
	'ACP_STOKER_CHAT_INITIAL_LOAD_EXPLAIN'		=> 'Number of newest messages to load when the chat first opens. A “Load older messages” link appears if more exist.<br>Set to 0 to disable this feature and load the maximum messages displayed (above) immediately.',
	'ACP_STOKER_CHAT_MAX_LENGTH'				=> 'Maximum message length',
	'ACP_STOKER_CHAT_MAX_LENGTH_EXPLAIN'		=> 'Maximum number of characters per chat message.',
	'ACP_STOKER_CHAT_PURGE_DAYS'				=> 'Purge messages older than',
	'ACP_STOKER_CHAT_PURGE_DAYS_EXPLAIN'		=> 'Messages older than this number of days will be automatically deleted.<br>Set to 0 to never purge.',
	'ACP_STOKER_CHAT_PURGE_DAYS_SUFFIX'			=> 'days',
	'ACP_STOKER_CHAT_INACTIVITY_MINUTES'		=> 'Inactivity lockdown',
	'ACP_STOKER_CHAT_INACTIVITY_MINUTES_EXPLAIN'=> 'Pause chat polling after this many minutes of user inactivity. The chat is greyed out and the user must click it to resume.<br>Set to 0 to disable. Reduces server load from browsers left open on a chat page.',
	'ACP_STOKER_CHAT_INACTIVITY_MINUTES_SUFFIX'	=> 'minutes',
	'ACP_STOKER_CHAT_TABHIDDEN_SECONDS'			=> 'Tab-switch lockdown',
	'ACP_STOKER_CHAT_TABHIDDEN_SECONDS_EXPLAIN'	=> 'Pause chat polling after the browser tab has been hidden for this many seconds. The chat is greyed out and the user must click it to resume.<br>Set to 0 to disable. Reduces server load from chat pages left open in background tabs.',
	'ACP_STOKER_CHAT_PURGE_NOW'					=> 'Purge all messages now',
	'ACP_STOKER_CHAT_PURGE_NOW_CONFIRM'			=> 'Delete all chat messages immediately? This action cannot be undone.',
	'ACP_STOKER_CHAT_PURGE_NOW_EXPLAIN'			=> 'Delete all chat messages immediately. This action cannot be undone.',
	'ACP_STOKER_CHAT_PURGE_BUTTON'				=> 'Purge now',
	'ACP_STOKER_CHAT_TOTAL_MESSAGES'			=> 'Active messages',
	'ACP_STOKER_CHAT_HIGHEST_ID'				=> 'Highest message ID',
	'ACP_STOKER_CHAT_SECONDS'					=> 'seconds',
	'ACP_STOKER_CHAT_MESSAGES'					=> 'messages',
	'ACP_STOKER_CHAT_CHARS'						=> 'characters',

	'ACP_STOKER_CHAT_FLOW'						=> 'Message flow direction',
	'ACP_STOKER_CHAT_FLOW_EXPLAIN'				=> 'Where new messages appear. “Newest at bottom” is the standard chat layout; “Newest at top” makes new messages slide down from the top.',
	'ACP_STOKER_CHAT_FLOW_BOTTOM'				=> 'Newest at bottom',
	'ACP_STOKER_CHAT_FLOW_TOP'					=> 'Newest at top',

	// Confirmations
	'ACP_STOKER_CHAT_SAVED'						=> 'Chat settings have been saved successfully.',
	'ACP_STOKER_CHAT_PURGED'					=> 'All chat messages have been purged.',

	// Emojis & BBCodes
	'ACP_STOKER_CHAT_EMOJI_LIST'				=> 'Emojis',
	'ACP_STOKER_CHAT_EMOJI_LIST_EXPLAIN'		=> 'Each row is one emoji. List the shortcodes that produce it, separated by spaces. These are replaced by the emoji when a message is sent.<br>Tick “In picker” to include the emoji in the desktop emoji button. An emoji with no shortcodes can still be picker-only.',
	'ACP_STOKER_CHAT_EMOJI_CHAR'				=> 'Emoji',
	'ACP_STOKER_CHAT_EMOJI_CODES'				=> 'Shortcodes',
	'ACP_STOKER_CHAT_EMOJI_PICKER'				=> 'In picker',
	'ACP_STOKER_CHAT_EMOJI_ADD'					=> 'Add emoji',
	'ACP_STOKER_CHAT_EMOJI_REMOVE'				=> 'Remove emoji',
	'ACP_STOKER_CHAT_BBCODES'					=> 'Disabled BBCodes',
	'ACP_STOKER_CHAT_BBCODES_EXPLAIN'			=> 'Ticked BBCodes are not allowed in chat. A message containing one is rejected with an error.<br>Both default and custom BBCodes are listed.',
	'ACP_STOKER_CHAT_EMOJI_SAVED'				=> 'Chat emojis and BBCodes have been saved successfully.',

	// Version check
	'ACP_STOKER_CHAT_VC_OK'						=> 'You are running the latest version (%s)',
	'ACP_STOKER_CHAT_VC_OUTDATED'				=> 'A new version is available: %2$s (you have %1$s). Click to download.',
	'ACP_STOKER_CHAT_VC_UNAVAILABLE'			=> 'Version check unavailable',

	'ACP_STOKER_CHAT_REQUIRE_PHP'				=> 'LiteChat requires PHP %1$s or later. Your version is %2$s.',
]);
