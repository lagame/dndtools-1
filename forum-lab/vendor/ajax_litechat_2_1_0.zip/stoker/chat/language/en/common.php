<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, [
	'STOKER_CHAT_TITLE'					=> 'LiteChat',
	'STOKER_CHAT_SEND'					=> 'Send',
	'STOKER_CHAT_EMOJI'					=> 'Emoji',
	'STOKER_CHAT_PLACEHOLDER'			=> 'Type a message…',
	'STOKER_CHAT_EMPTY'					=> 'Please enter a message.',
	'STOKER_CHAT_TOO_LONG'				=> 'Your message is too long.',
	'STOKER_CHAT_NO_MESSAGES'			=> 'No messages yet. Be the first to say something!',
	'STOKER_CHAT_LOAD_OLDER'			=> 'Load older messages',
	'STOKER_CHAT_LOAD_OLDER_LOADING'	=> 'Loading…',
	'STOKER_CHAT_EDIT'					=> 'Edit',
	'STOKER_CHAT_EDIT_SAVE'				=> 'Save',
	'STOKER_CHAT_EDIT_CANCEL'			=> 'Cancel',
	'STOKER_CHAT_EDITED'				=> 'edited',
	'STOKER_CHAT_DELETE'				=> 'Delete',
	'STOKER_CHAT_DELETE_CONFIRM'		=> 'Are you sure you want to delete this message?',
	'STOKER_CHAT_QUOTE'					=> 'Quote',
	'STOKER_CHAT_LIKE'					=> 'Like',
	'STOKER_CHAT_MENU'					=> 'Actions',
	'STOKER_CHAT_OPEN'					=> 'Open chat in full page',
	'STOKER_CHAT_ERROR'					=> 'An error occurred. Please try again.',
	'STOKER_CHAT_LOGIN'					=> 'You must be logged in to chat.',
	'STOKER_CHAT_NOT_AUTHORISED'		=> 'You are not authorised to do this.',
	'STOKER_CHAT_NO_USE'				=> 'You do not have permission to post in the chat.',
	'STOKER_CHAT_NOT_FOUND'				=> 'That message no longer exists.',
	'STOKER_CHAT_INVALID_ID'			=> 'Invalid message ID.',
	'STOKER_CHAT_FLOOD'					=> [
		1 => 'Please wait %d more second before posting again.',
		2 => 'Please wait %d more seconds before posting again.',
	],
	'STOKER_CHAT_BBCODE_NOT_ALLOWED'	=> 'The BBCode [%s] is not allowed.',
	'STOKER_CHAT_PAUSED'				=> 'Chat paused',
	'STOKER_CHAT_RESUME'				=> 'Click to resume',
	'STOKER_CHAT_JS_REQUIRED'			=> 'JavaScript is required to use the chat.<br>Please enable it in your browser.',
	'STOKER_CHAT_CREDIT'				=> 'LiteChat © PhpBB3 BBCodes',
	'VIEWONLINE_STOKER_CHAT'			=> 'Viewing LiteChat',

	'STOKER_CHAT_COLLAPSIBLE_TITLE' => [
		0 => 'Hide LiteChat',
		1 => 'Show LiteChat',
	],
]);
