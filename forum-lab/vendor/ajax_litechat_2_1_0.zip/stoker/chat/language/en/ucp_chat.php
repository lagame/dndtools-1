<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, [
	'UCP_STOKER_CHAT_EXPLAIN'					=> 'These settings let you personalise the LiteChat for your own account.<br>Leave any option on “Use board default” to follow the board-wide setting chosen by the administrator.',

	'UCP_STOKER_CHAT_USE_DEFAULT'				=> 'Use board default',

	'UCP_STOKER_CHAT_INDEX_ENABLE'				=> 'Display LiteChat on forum index',
	'UCP_STOKER_CHAT_INDEX_ENABLE_EXPLAIN'		=> 'Show the LiteChat widget on the forum index page.',
	'UCP_STOKER_CHAT_INDEX_POSITION'			=> 'LiteChat position on forum index',
	'UCP_STOKER_CHAT_INDEX_POSITION_EXPLAIN'	=> 'Where to display the LiteChat widget relative to the forum list.',
	'UCP_STOKER_CHAT_INDEX_TOP'					=> 'Above the forum list',
	'UCP_STOKER_CHAT_INDEX_BOTTOM'				=> 'Below the forum list',

	'UCP_STOKER_CHAT_PORTAL_ENABLE'				=> 'Display LiteChat on Portal',
	'UCP_STOKER_CHAT_PORTAL_ENABLE_EXPLAIN'		=> 'Show the LiteChat widget on the portal page.',
	'UCP_STOKER_CHAT_PORTAL_POSITION'			=> 'LiteChat position on Portal page',
	'UCP_STOKER_CHAT_PORTAL_POSITION_EXPLAIN'	=> 'Where to display the LiteChat widget on the Portal page.',
	'UCP_STOKER_CHAT_PORTAL_TOP'				=> 'Top of the Portal',
	'UCP_STOKER_CHAT_PORTAL_MIDDLE'				=> 'Middle of the Portal',
	'UCP_STOKER_CHAT_PORTAL_BOTTOM'				=> 'Bottom of the Portal',

	'UCP_STOKER_CHAT_ACTION_BAR'				=> 'Message action bar',
	'UCP_STOKER_CHAT_ACTION_BAR_EXPLAIN'		=> 'How the per-message actions (quote, like, edit, delete) are presented.',
	'UCP_STOKER_CHAT_ACTION_BAR_RESPONSIVE'		=> 'Responsive - icons on desktop, menu on mobile',
	'UCP_STOKER_CHAT_ACTION_BAR_MENU'			=> 'Always a menu',
	'UCP_STOKER_CHAT_ACTION_BAR_ICONS'			=> 'Always icons - never a menu',

	'UCP_STOKER_CHAT_FLOW'						=> 'Message flow direction',
	'UCP_STOKER_CHAT_FLOW_EXPLAIN'				=> 'Where new messages appear in the chat.',
	'UCP_STOKER_CHAT_FLOW_BOTTOM'				=> 'Newest at bottom',
	'UCP_STOKER_CHAT_FLOW_TOP'					=> 'Newest at top',

	'STOKER_CHAT_PREFS_SAVED'					=> 'Your LiteChat preferences have been updated.',
]);
