## [2.1.0]

### Added
- Addon API, so other extensions can hook into the chat:
  - PHP events: `stoker.chat.template_vars`, `stoker.chat.post_before`, `stoker.chat.post_handle`, `stoker.chat.post_after`, `stoker.chat.edit_before`, `stoker.chat.edit_after`, `stoker.chat.delete_after`, `stoker.chat.modify_messages` and `stoker.chat.fetch_response`. Core template variables, message keys and response keys cannot be overwritten by subscribers.
  - `stoker.chat.post_handle` fires after validation and the flood check, so an addon can handle a message (e.g. a chat command) without it being stored. Handled messages do not count toward the flood interval; addons must rate-limit their own commands.
  - A `stoker.chat.message_manager` service with `add_message()`, so extensions can post messages (bots, system messages) through the same parsing and BBCode blacklist as the chat.
  - Template events in the chat widget: `stoker_chat_widget_header_after`, `stoker_chat_widget_messages_before`, `stoker_chat_widget_messages_after`, `stoker_chat_widget_input_buttons_before`, `stoker_chat_widget_input_after` and `stoker_chat_widget_after`.
  - A JavaScript API, queued through `window.stokerChatAddons` so load order does not matter: per-message menu actions (`registerAction`), `insertAtCursor`, `refresh` and escaping helpers, plus the jQuery events `stoker_chat_ready`, `stoker_chat_messages_rendered`, `stoker_chat_message_updated`, `stoker_chat_before_send` and `stoker_chat_poll_done` on `#stoker-chat`.

### Security
- Posting, editing and deleting now require `u_stoker_chat_view` as well as `u_stoker_chat_use`.
- Edit and delete buttons are only shown to users with `u_stoker_chat_use`, matching what the server already enforced.
- The JSON responses no longer include `user_id`, `message_time` or `is_owner`.

### Fixed
- Users who only chatted, without loading other pages, were logged out after the session length and dropped off Who is Online. JSON responses never reach page_header(), so the session was never refreshed. The fetch, post, edit and delete endpoints now call update_session_infos().
- Usernames with special characters (e.g. `Tom & Jerry`) were shown double-escaped.
- Messages from deleted users now show "Guest" with the default avatar.
- Message length is now counted in code points on the client, matching the server. Messages with emoji are no longer rejected below the real limit.
- Quote, Like and username click no longer insert BBCodes that are disabled in the ACP. Quote and Like are hidden when `[quote]` is disabled.
- Quoted text containing `[` is no longer stored as a literal `&#91;`.
- Quoting no longer depends on the English "wrote:" text, so it works on non-English boards.
- An edit made by someone else while you are editing the same message is no longer lost. It is applied if you cancel.
- The disallowed-BBCode check now also catches tags with named attributes.
- The edited-messages query in delta polls is now capped at the max-messages setting.
- The deleted-messages query in delta polls is now capped at the max-messages setting, newest first.
- Symbols such as ©, ® and ™ were enlarged as emoji. Flag and keycap emoji were not enlarged.
- `ext.php`: `is_enableable()` returned a truthy array on phpBB versions below 3.3.
- Pressing Enter in an ACP settings field now saves the form instead of opening the purge confirm.
- A failed ACP toggle (index/portal display) now shows an error instead of failing silently.
- ACP emoji "In picker" is now a real checkbox, so Reset restores it correctly.
- The ACP emoji delete button font size had no effect.
- The Ext Check link is no longer hardcoded to a single version.
- UCP: an invalid form submission is now shown as an error instead of an information notice.
- Standalone chat page: the online list now uses prosilver markup and no longer fires the core `index_body_block_online_*` events outside the index.
- The flood message now uses plural forms.
- The ACP support link now points to the extension's support topic instead of the site's front page.
- A sent message or Like could take a full poll interval to appear when a poll was already running at the moment it was posted.
- Pressing Enter to confirm IME input (Chinese, Japanese, Korean) sent the message, or saved the edit, before the input was finished.
- A chat collapsed with Collapsible Categories still loaded its messages on every page view. It now loads when it is expanded.
- When the server refuses a chat request (permission removed, logged out in another tab), polling now stops and the reason is shown in the chat. Before, polling continued until the lockdown or a page reload.
- After an inactivity or tab-switch lockdown in a busy chat, resuming showed the missed messages oldest first, one batch per poll interval, before reaching the newest. When more new messages exist than the chat displays, it now shows the newest batch at once and offers the rest through "Load older messages".
- Who is Online showed users on other extensions' pages whose route starts with `/chat` (e.g. `/chatbox`) as "Viewing LiteChat".
- The ACP and UCP portal display explain texts said the chat is shown "right under the welcome message", although the portal position is configurable.

### Changed
- "Purge now" soft-deletes all messages, so open chats remove them on the next poll. The daily cron deletes the rows after about 24 hours. The age-based purge skips these rows and does not count them toward the 20 messages it always keeps.
- Polling is skipped while the widget is collapsed with Collapsible Categories.
- Version check: the badge is rendered locally from `composer.json` instead of img.shields.io. A failed check is cached for one hour.
- The ACP stats and "Purge now" block moved below Submit/Reset and is now its own form.
- ACP BBCode explain text now says a message containing a disabled BBCode is rejected.
- ACP lockdown explain texts no longer claim the lockdown prevents logouts. They now say it reduces server load.
- The ACP stat "Total all-time messages" is renamed "Highest message ID", which is what it shows.
- The emoji/BBCode settings and widget template variables moved to a new `chat_helper` service. The forum index and portal no longer load the text formatter parser.
- Message parsing and storing moved from the chat controller to the new `message_manager` service. Before parsing, it sets every option the chat depends on (BBCodes, magic URLs, smilies, and the img, flash, quote and url tags) on the shared text formatter parser, so a message added in the same request as a forum post is not affected by that post's options or the poster's BBCode permissions. Afterwards, smilies and the BBCodes disabled for the chat are reset to the parser defaults.
- The `message_manager` service is lazy-loaded, so chat polls, the standalone page and deletes no longer load the text formatter parser. Only posting and editing load it.
- Language keys `CHAT_PORTAL_NOT_AVAILABLE` and `CHAT_REQUIRE_PHP` are renamed `ACP_STOKER_CHAT_PORTAL_NOT_AVAILABLE` and `ACP_STOKER_CHAT_REQUIRE_PHP`, so they cannot collide with other extensions. Translations must rename them too.

### Removed
- The `stoker.chat.main_controller_render_template_before` event. Use `stoker.chat.template_vars`, which also fires for the widget on the index and portal.
- Dead `method_exists()` checks in the ACP and UCP controllers.
- Unused template variables `S_STOKER_CHAT_EDIT`, `S_STOKER_CHAT_DELETE` and `S_STOKER_CHAT_MOD`, and the unused `time_format` in the edit response.
- Unused JavaScript data and parameters (`original-html`, `timeFormat`), and the unused `data-paused-label` and `data-resume-label` attributes.
- The never-assigned `S_ERROR` / `ERROR_MSG` blocks in both ACP templates, and the never-assigned `S_FORM_ENCTYPE` in the UCP template.
- Duplicate language keys `STOKER_LITE_CHAT_TITLE` and `UCP_STOKER_CHAT_TITLE` (in `ucp_chat.php`), and the unused `ACP_SUBMIT_CHANGES` and `CHAT_REQUIRE_PHPBB` keys.
- Unused announcement URL in the version check.
- Duplicate emoji helper methods in the main and ACP controllers.
- A dead `functions_display` include check in the avatar code, and the chat controller's now-unused `php_ext` argument.
- The browser-title unread counter in chat.js. It never fired, because polling stops while the tab is hidden.
- The legend line in the standalone chat page's online list. It never rendered, because only the forum index assigns `LEGEND`.
