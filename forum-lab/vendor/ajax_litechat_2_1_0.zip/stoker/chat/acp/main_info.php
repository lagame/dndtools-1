<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\acp;

class main_info
{
	/**
	 * @return array
	 */
	public function module()
	{
		return [
			'filename'	=> '\stoker\chat\acp\main_module',
			'title'		=> 'ACP_STOKER_CHAT_TITLE',
			'modes'		=> [
				'settings'	=> [
					'title'	=> 'ACP_STOKER_CHAT_SETTINGS',
					'auth'	=> 'ext_stoker/chat && acl_a_board',
					'cat'	=> ['ACP_STOKER_CHAT_TITLE'],
				],
				'emoji_bbcode'	=> [
					'title'	=> 'ACP_STOKER_CHAT_EMOJIS',
					'auth'	=> 'ext_stoker/chat && acl_a_board',
					'cat'	=> ['ACP_STOKER_CHAT_TITLE'],
				],
			],
		];
	}
}
