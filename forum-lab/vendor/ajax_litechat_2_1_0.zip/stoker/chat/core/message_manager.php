<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\core;

use phpbb\db\driver\driver_interface;
use phpbb\textformatter\parser_interface;

/**
 * Stores chat messages. The single write path for the chat controller and for other extensions.
 */
class message_manager
{
	/** @var chat_helper */
	protected $chat_helper;

	/** @var driver_interface */
	protected $db;

	/** @var parser_interface */
	protected $parser;

	/** @var string */
	protected $chat_table;

	/**
	 * @param chat_helper		$chat_helper
	 * @param driver_interface	$db
	 * @param parser_interface	$parser
	 * @param string			$chat_table
	 */
	public function __construct(chat_helper $chat_helper, driver_interface $db, parser_interface $parser, string $chat_table)
	{
		$this->chat_helper = $chat_helper;
		$this->db = $db;
		$this->parser = $parser;
		$this->chat_table = $chat_table;
	}

	/**
	 * Add a message to the chat. Permissions, flood interval and length are not
	 * checked here; callers are responsible for those.
	 *
	 * @param int    $user_id Author user ID (ANONYMOUS for system messages)
	 * @param string $message Raw message text with BBCode, not HTML-encoded
	 * @return int New message ID, or 0 if the message is empty
	 */
	public function add_message(int $user_id, string $message): int
	{
		$message = trim($message, " \n\r\t\v\x00");
		if ($message === '')
		{
			return 0;
		}

		$sql_ary = [
			'user_id'		=> $user_id,
			'message'		=> $this->parse($message),
			'message_time'	=> time(),
			'edit_time'		=> 0,
		];

		$sql = 'INSERT INTO ' . $this->chat_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);

		return (int) $this->db->sql_nextid();
	}

	/**
	 * Parse raw text for storage. The parser is a shared service and core's message_parser
	 * leaves its options set after each parse, so every option the chat depends on is set
	 * explicitly first. Disallowed BBCodes are disabled up front so the parser leaves them as
	 * literal text rather than recognising and tagging them — this avoids the empty-output
	 * edge case where a stray "*" would be parsed as a list item then stripped to nothing.
	 * Smilies and the disabled BBCodes are restored to the parser defaults afterwards; the
	 * parser has no getter for its previous state, and core sets every option before each parse.
	 *
	 * @param string $message
	 * @return string
	 */
	public function parse(string $message): string
	{
		$disabled = $this->chat_helper->get_emoji_bbcode_set()['disabled_bbcodes'];

		$this->parser->enable_bbcodes();
		$this->parser->enable_magic_url();
		$this->parser->disable_smilies();

		// Tags core's message_parser disables per user permission
		foreach (array_diff(['flash', 'img', 'quote', 'url'], $disabled) as $bbcode)
		{
			$this->parser->enable_bbcode($bbcode);
		}

		foreach ($disabled as $bbcode)
		{
			$this->parser->disable_bbcode($bbcode);
		}

		try
		{
			return $this->parser->parse($message);
		}
		finally
		{
			$this->parser->enable_smilies();
			foreach ($disabled as $bbcode)
			{
				$this->parser->enable_bbcode($bbcode);
			}
		}
	}
}
