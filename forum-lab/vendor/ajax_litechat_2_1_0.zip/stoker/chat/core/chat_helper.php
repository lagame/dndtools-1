<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\core;

use phpbb\auth\auth;
use phpbb\cache\service;
use phpbb\config\config;
use phpbb\config\db_text;
use phpbb\controller\helper;
use phpbb\event\dispatcher_interface;
use phpbb\user;

/**
 * Shared chat helper: emoji/BBCode settings and widget template vars.
 * Has no text formatter dependency, so it is cheap to load on index and portal.
 */
class chat_helper
{
	/** @var string Cache key for the merged emoji map + disabled BBCode set. */
	const EMOJI_BBCODE_CACHE_KEY = '_stoker_chat_emoji_bbcode';

	/** @var string config_text key holding the emoji map + disabled BBCode set as JSON. */
	const EMOJI_BBCODE_CONFIG_KEY = 'stoker_chat_emoji_bbcode';

	/** @var auth */
	protected $auth;

	/** @var service */
	protected $cache;

	/** @var config */
	protected $config;

	/** @var db_text */
	protected $config_text;

	/** @var dispatcher_interface */
	protected $dispatcher;

	/** @var helper */
	protected $helper;

	/** @var user */
	protected $user;

	/** @var array|null Per-request memo of the decoded emoji/BBCode set. */
	protected $emoji_bbcode_set = null;

	/**
	 * @param auth					$auth
	 * @param service				$cache
	 * @param config				$config
	 * @param db_text				$config_text
	 * @param dispatcher_interface	$dispatcher
	 * @param helper				$helper
	 * @param user					$user
	 */
	public function __construct(auth $auth, service $cache, config $config, db_text $config_text, dispatcher_interface $dispatcher, helper $helper, user $user)
	{
		$this->auth = $auth;
		$this->cache = $cache;
		$this->config = $config;
		$this->config_text = $config_text;
		$this->dispatcher = $dispatcher;
		$this->helper = $helper;
		$this->user = $user;
	}

	/**
	 * Build the template vars shared by standalone page and index widget.
	 *
	 * @param bool $standalone
	 * @return array
	 */
	public function get_chat_vars(bool $standalone): array
	{
		$set = $this->get_emoji_bbcode_set();
		$emojis = $this->normalize_emojis($set['emojis']);

		$template_vars = [
			'STOKER_CHAT_POLL_INTERVAL'		=> (int) $this->config['stoker_chat_poll_interval'],
			'STOKER_CHAT_MAX_LENGTH'		=> (int) $this->config['stoker_chat_max_length'],
			'STOKER_CHAT_MAX_MESSAGES'		=> (int) $this->config['stoker_chat_max_messages'],
			'STOKER_CHAT_INACTIVITY_MS'		=> (int) $this->config['stoker_chat_inactivity_minutes'] * 60000,
			'STOKER_CHAT_TABHIDDEN_MS'		=> (int) $this->config['stoker_chat_tabhidden_seconds'] * 1000,
			'STOKER_CHAT_ACTION_BAR'		=> $this->resolve_action_bar(),
			'STOKER_CHAT_FLOW'				=> $this->resolve_flow(),
			'STOKER_CHAT_HASH'				=> generate_link_hash('stoker_chat'),
			'STOKER_CHAT_EMOJI_MAP'			=> json_encode((object) $this->emoji_shortcode_map($emojis)),
			'STOKER_CHAT_PICKER_EMOJIS'		=> json_encode($this->emoji_picker_list($emojis)),
			'STOKER_CHAT_DISABLED_BBCODES'	=> json_encode(array_values($set['disabled_bbcodes'])),
			'S_STOKER_CHAT_USE'				=> $this->auth->acl_get('u_stoker_chat_use'),
			'U_STOKER_CHAT_FETCH'			=> $this->helper->route('stoker_chat_fetch'),
			'U_STOKER_CHAT_POST'			=> $this->helper->route('stoker_chat_post'),
			'U_STOKER_CHAT_EDIT'			=> $this->helper->route('stoker_chat_edit'),
			'U_STOKER_CHAT_DELETE'			=> $this->helper->route('stoker_chat_delete'),
			'S_STOKER_CHAT_STANDALONE'		=> $standalone,
		];
		$core_vars = $template_vars;

		/**
		 * Add template variables for the chat widget (index, portal and standalone page)
		 *
		 * @event stoker.chat.template_vars
		 * @var array template_vars Template variables array
		 * @var bool  standalone    True on the standalone chat page
		 * @since 2.1.0
		 */
		$vars = ['template_vars', 'standalone'];
		extract($this->dispatcher->trigger_event('stoker.chat.template_vars', compact($vars)));

		// Re-apply core vars last so subscribers cannot overwrite them
		return array_merge($template_vars, $core_vars);
	}

	/**
	 * Return the emoji map + disabled BBCode set, cached per request and via the data cache.
	 *
	 * @return array
	 */
	public function get_emoji_bbcode_set(): array
	{
		if ($this->emoji_bbcode_set !== null)
		{
			return $this->emoji_bbcode_set;
		}

		$set = $this->cache->get(self::EMOJI_BBCODE_CACHE_KEY);

		if ($set === false)
		{
			$set = $this->load_emoji_bbcode_set();
			$this->cache->put(self::EMOJI_BBCODE_CACHE_KEY, $set);
		}

		$this->emoji_bbcode_set = $set;

		return $set;
	}

	/**
	 * Decode the emoji map + disabled BBCode set from config_text (un-cached).
	 *
	 * @return array
	 */
	public function load_emoji_bbcode_set(): array
	{
		$defaults = ['emojis' => [], 'disabled_bbcodes' => []];

		$raw = $this->config_text->get(self::EMOJI_BBCODE_CONFIG_KEY);

		if ($raw === null || $raw === '')
		{
			return $defaults;
		}

		$decoded = json_decode($raw, true);

		if (!is_array($decoded))
		{
			return $defaults;
		}

		return [
			'emojis'           => (isset($decoded['emojis']) && is_array($decoded['emojis'])) ? $decoded['emojis'] : [],
			'disabled_bbcodes' => (isset($decoded['disabled_bbcodes']) && is_array($decoded['disabled_bbcodes'])) ? array_values($decoded['disabled_bbcodes']) : [],
		];
	}

	/**
	 * Store the emoji map + disabled BBCode set and invalidate the cached copy.
	 *
	 * @param array $emojis
	 * @param array $disabled_bbcodes
	 * @return void
	 */
	public function save_emoji_bbcode_set(array $emojis, array $disabled_bbcodes): void
	{
		$payload = json_encode([
			'emojis'           => $emojis,
			'disabled_bbcodes' => array_values(array_unique($disabled_bbcodes)),
		]);

		$this->config_text->set(self::EMOJI_BBCODE_CONFIG_KEY, $payload);
		$this->cache->destroy(self::EMOJI_BBCODE_CACHE_KEY);
		$this->emoji_bbcode_set = null;
	}

	/**
	 * Normalise the stored emoji structure into a list of {emoji, shortcodes[], in_picker}
	 * entries. Accepts both the current grouped shape and the legacy flat shortcode => emoji
	 * map so a board that has not yet run the conversion migration still renders correctly.
	 *
	 * @param mixed $emojis
	 * @return array
	 */
	public function normalize_emojis($emojis): array
	{
		if (!is_array($emojis) || empty($emojis))
		{
			return [];
		}

		$first = reset($emojis);

		// Current shape: a list of grouped entries.
		if (is_array($first))
		{
			$out = [];

			foreach ($emojis as $entry)
			{
				if (!is_array($entry) || !isset($entry['emoji']) || (string) $entry['emoji'] === '')
				{
					continue;
				}

				$shortcodes = [];
				if (isset($entry['shortcodes']) && is_array($entry['shortcodes']))
				{
					foreach ($entry['shortcodes'] as $code)
					{
						$code = trim((string) $code, " \n\r\t\v\x00");
						if ($code !== '' && !in_array($code, $shortcodes, true))
						{
							$shortcodes[] = $code;
						}
					}
				}

				$out[] = [
					'emoji'			=> (string) $entry['emoji'],
					'shortcodes'	=> $shortcodes,
					'in_picker'		=> !empty($entry['in_picker']),
				];
			}

			return $out;
		}

		// Legacy shape: flat shortcode => emoji map. Group by emoji, default to in_picker.
		$grouped = [];

		foreach ($emojis as $code => $emoji)
		{
			$code = trim((string) $code, " \n\r\t\v\x00");
			$emoji = (string) $emoji;

			if ($code === '' || $emoji === '')
			{
				continue;
			}

			if (!isset($grouped[$emoji]))
			{
				$grouped[$emoji] = ['emoji' => $emoji, 'shortcodes' => [], 'in_picker' => true];
			}

			if (!in_array($code, $grouped[$emoji]['shortcodes'], true))
			{
				$grouped[$emoji]['shortcodes'][] = $code;
			}
		}

		return array_values($grouped);
	}

	/**
	 * Flatten grouped emoji entries into a shortcode => emoji map for client-side conversion.
	 *
	 * @param array $emojis
	 * @return array
	 */
	protected function emoji_shortcode_map(array $emojis): array
	{
		$map = [];

		foreach ($emojis as $entry)
		{
			foreach ($entry['shortcodes'] as $code)
			{
				$map[$code] = $entry['emoji'];
			}
		}

		return $map;
	}

	/**
	 * Return the ordered list of emoji flagged for the desktop picker.
	 *
	 * @param array $emojis
	 * @return array
	 */
	protected function emoji_picker_list(array $emojis): array
	{
		$list = [];

		foreach ($emojis as $entry)
		{
			if ($entry['in_picker'])
			{
				$list[] = $entry['emoji'];
			}
		}

		return $list;
	}

	/**
	 * Resolve the message action-bar mode, letting a per-user override (-1 = use
	 * board default) take precedence over the board-wide setting.
	 *
	 * @return int
	 */
	private function resolve_action_bar(): int
	{
		$value = isset($this->user->data['user_stoker_chat_action_bar']) ? (int) $this->user->data['user_stoker_chat_action_bar'] : -1;

		return $value === -1 ? (int) ($this->config['stoker_chat_action_bar'] ?? 0) : $value;
	}

	/**
	 * Resolve the message flow direction, letting a per-user override (-1 = use
	 * board default) take precedence over the board-wide setting.
	 * 0 = newest at bottom (default), 1 = newest at top.
	 *
	 * @return int
	 */
	private function resolve_flow(): int
	{
		$value = isset($this->user->data['user_stoker_chat_flow']) ? (int) $this->user->data['user_stoker_chat_flow'] : -1;

		return $value === -1 ? (int) ($this->config['stoker_chat_flow'] ?? 0) : $value;
	}
}
