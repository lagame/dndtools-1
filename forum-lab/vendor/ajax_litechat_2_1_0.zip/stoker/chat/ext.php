<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat;

class ext extends \phpbb\extension\base
{
	/**
	 * Enable extension if minimum requirements are met.
	 *
	 * - Requires phpBB >= 3.3.0
	 * - Requires PHP  >= 7.4.0
	 *
	 * @return bool|array
	 */
	public function is_enableable()
	{
		$config = $this->container->get('config');

		$required_phpbb = '3.3.0';
		$required_php = '7.4.0';

		// phpBB below 3.3 treats a returned array as truthy, so only false blocks it there
		if (!phpbb_version_compare($config['version'], $required_phpbb, '>='))
		{
			return false;
		}

		if (!version_compare(PHP_VERSION, $required_php, '>='))
		{
			$language = $this->container->get('language');
			$language->add_lang('acp_chat', 'stoker/chat');

			return [$language->lang('ACP_STOKER_CHAT_REQUIRE_PHP', $required_php, PHP_VERSION)];
		}

		return true;
	}
}
