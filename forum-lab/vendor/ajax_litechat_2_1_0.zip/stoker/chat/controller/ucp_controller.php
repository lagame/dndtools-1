<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\controller;

use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\extension\manager;
use phpbb\language\language;
use phpbb\request\request;
use phpbb\template\template;
use phpbb\user;

class ucp_controller
{
	/** @var config */
	protected $config;

	/** @var driver_interface */
	protected $db;

	/** @var manager */
	protected $ext_manager;

	/** @var language */
	protected $language;

	/** @var request */
	protected $request;

	/** @var template */
	protected $template;

	/** @var user */
	protected $user;

	/** @var string */
	protected $u_action;

	/**
	 * @param config			$config
	 * @param driver_interface	$db
	 * @param manager			$ext_manager
	 * @param language			$language
	 * @param request			$request
	 * @param template			$template
	 * @param user				$user
	 */
	public function __construct(config $config, driver_interface $db, manager $ext_manager, language $language, request $request, template $template, user $user)
	{
		$this->config = $config;
		$this->db = $db;
		$this->ext_manager = $ext_manager;
		$this->language = $language;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
	}

	/**
	 * @param string $u_action
	 * @return void
	 */
	public function set_page_url(string $u_action): void
	{
		$this->u_action = $u_action;
	}

	/**
	 * Display the per-user chat preference form
	 *
	 * @return void
	 */
	public function display_settings(): void
	{
		add_form_key('stoker_chat_ucp');

		$this->language->add_lang('ucp_chat', 'stoker/chat');

		$portal_available = $this->ext_manager->is_enabled('stoker/portal') && !empty($this->config['acp_portal_enable']);

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key('stoker_chat_ucp'))
			{
				trigger_error($this->language->lang('FORM_INVALID'), E_USER_WARNING);
			}

			$sql_ary = [
				'user_stoker_chat_index_enable'		=> $this->sanitise('user_stoker_chat_index_enable', [-1, 0, 1]),
				'user_stoker_chat_index_pos'	=> $this->sanitise('user_stoker_chat_index_pos', [-1, 0, 1]),
				'user_stoker_chat_action_bar'		=> $this->sanitise('user_stoker_chat_action_bar', [-1, 0, 1, 2]),
				'user_stoker_chat_flow'				=> $this->sanitise('user_stoker_chat_flow', [-1, 0, 1]),
			];

			// Only persist portal overrides when the portal surface actually exists,
			// otherwise hidden fields would be written back as "use board default".
			if ($portal_available)
			{
				$sql_ary['user_stoker_chat_portal_enable'] = $this->sanitise('user_stoker_chat_portal_enable', [-1, 0, 1]);
				$sql_ary['user_stoker_chat_portal_pos'] = $this->sanitise('user_stoker_chat_portal_pos', [-1, 0, 1, 2]);
			}

			$sql = 'UPDATE ' . USERS_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE user_id = ' . (int) $this->user->data['user_id'];
			$this->db->sql_query($sql);

			// Keep the in-memory session row consistent for the rest of this request.
			foreach ($sql_ary as $column => $value)
			{
				$this->user->data[$column] = $value;
			}

			meta_refresh(3, $this->u_action);
			trigger_error($this->language->lang('STOKER_CHAT_PREFS_SAVED') . '<br><br>' . $this->language->lang('RETURN_UCP', '<a href="' . $this->u_action . '">', '</a>'));
		}

		$this->template->assign_vars([
			'S_UCP_ACTION'					=> $this->u_action,
			'S_PORTAL_AVAILABLE'			=> $portal_available,
			'STOKER_CHAT_INDEX_ENABLE'		=> $this->current('user_stoker_chat_index_enable'),
			'STOKER_CHAT_INDEX_POSITION'	=> $this->current('user_stoker_chat_index_pos'),
			'STOKER_CHAT_PORTAL_ENABLE'		=> $this->current('user_stoker_chat_portal_enable'),
			'STOKER_CHAT_PORTAL_POSITION'	=> $this->current('user_stoker_chat_portal_pos'),
			'STOKER_CHAT_ACTION_BAR'		=> $this->current('user_stoker_chat_action_bar'),
			'STOKER_CHAT_FLOW'				=> $this->current('user_stoker_chat_flow'),
		]);
	}

	/**
	 * Read a submitted override, falling back to the stored value and clamping to the allowed set.
	 *
	 * @param string $key
	 * @param array  $allowed
	 * @return int
	 */
	private function sanitise(string $key, array $allowed): int
	{
		$value = $this->request->variable($key, $this->current($key));

		return in_array($value, $allowed, true) ? $value : -1;
	}

	/**
	 * Stored override value for a column, defaulting to -1 (use board default).
	 *
	 * @param string $key
	 * @return int
	 */
	private function current(string $key): int
	{
		return isset($this->user->data[$key]) ? (int) $this->user->data[$key] : -1;
	}
}
