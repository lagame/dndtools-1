<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\controller;

use phpbb\cache\service;
use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\extension\manager;
use phpbb\file_downloader;
use phpbb\language\language;
use phpbb\log\log;
use phpbb\request\request;
use phpbb\template\template;
use phpbb\user;
use phpbb\version_helper;
use stoker\chat\core\chat_helper;

class acp_controller
{
	/** Seconds before a failed version check is retried */
	protected const VERSIONCHECK_RETRY_TTL = 3600;

	/** @var service */
	protected $cache;

	/** @var config */
	protected $config;

	/** @var chat_helper */
	protected $chat_helper;

	/** @var driver_interface */
	protected $db;

	/** @var manager */
	protected $ext_manager;

	/** @var file_downloader */
	protected $file_downloader;

	/** @var language */
	protected $language;

	/** @var log */
	protected $log;

	/** @var request */
	protected $request;

	/** @var template */
	protected $template;

	/** @var user */
	protected $user;

	/** @var string */
	protected $chat_table;

	/** @var string */
	protected $u_action;

	/**
	 * @param service			$cache
	 * @param chat_helper		$chat_helper
	 * @param config			$config
	 * @param driver_interface	$db
	 * @param manager			$ext_manager
	 * @param file_downloader	$file_downloader
	 * @param language			$language
	 * @param log				$log
	 * @param request			$request
	 * @param template			$template
	 * @param user				$user
	 * @param string			$chat_table
	 */
	public function __construct(service $cache, chat_helper $chat_helper, config $config, driver_interface $db, manager $ext_manager, file_downloader $file_downloader, language $language, log $log, request $request, template $template, user $user, string $chat_table)
	{
		$this->cache = $cache;
		$this->chat_helper = $chat_helper;
		$this->config = $config;
		$this->db = $db;
		$this->ext_manager = $ext_manager;
		$this->file_downloader = $file_downloader;
		$this->language = $language;
		$this->log = $log;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->chat_table = $chat_table;
	}

	/**
	 * @param string $u_action
	 * @return void
	 */
	public function set_page_url(string $u_action): void
	{
		$this->u_action = $u_action;
	}

	/**
	 * Display the Emojis & BBCodes page
	 *
	 * @return void
	 */
	public function display_emoji_bbcode(): void
	{
		$this->language->add_lang('acp_chat', 'stoker/chat');

		$this->assign_version_check_vars();

		add_form_key('stoker_chat_acp');

		// Full list of disable-able BBCodes: core defaults + custom (from the bbcodes table).
		$bbcode_list = $this->get_bbcode_list();

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key('stoker_chat_acp'))
			{
				trigger_error($this->language->lang('FORM_INVALID'), E_USER_WARNING);
			}

			// Emojis: one grouped {emoji, shortcodes[], in_picker} entry per table row.
			$emojis = $this->parse_emoji_table();

			// BBCodes: a checked box means the BBCode is disabled in chat. Whitelist against the known list.
			$checked  = $this->request->variable('stoker_chat_disabled_bbcodes', ['']);
			$disabled = [];
			foreach ($checked as $tag)
			{
				if ($tag !== '' && in_array($tag, $bbcode_list, true))
				{
					$disabled[] = $tag;
				}
			}

			$this->chat_helper->save_emoji_bbcode_set($emojis, $disabled);

			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ACP_STOKER_CHAT_EMOJI');

			trigger_error($this->language->lang('ACP_STOKER_CHAT_EMOJI_SAVED') . adm_back_link($this->u_action));
		}

		$set = $this->chat_helper->load_emoji_bbcode_set();
		$emojis = $this->chat_helper->normalize_emojis($set['emojis']);

		foreach ($emojis as $i => $entry)
		{
			$this->template->assign_block_vars('emoji_rows', [
				'INDEX'			=> $i,
				'EMOJI'			=> $entry['emoji'],
				'SHORTCODES'	=> implode(' ', $entry['shortcodes']),
				'S_IN_PICKER'	=> $entry['in_picker'],
			]);
		}

		foreach ($bbcode_list as $tag)
		{
			$this->template->assign_block_vars('bbcodes', [
				'TAG'			=> $tag,
				'S_DISABLED'	=> in_array($tag, $set['disabled_bbcodes'], true),
			]);
		}

		$this->template->assign_vars([
			'U_ACTION'	=> $this->u_action,
		]);
	}

	/**
	 * Parse the submitted emoji table into a list of grouped entries. Rows are keyed by an
	 * explicit index shared across the char/codes/picker inputs, so deletions on the client
	 * leave gaps without misaligning the picker flags.
	 *
	 * @return array
	 */
	private function parse_emoji_table(): array
	{
		$chars  = $this->request->variable('emoji_char', [''], true);
		$codes  = $this->request->variable('emoji_codes', [''], true);
		$picker = $this->request->variable('emoji_picker', [0 => 0]);

		$emojis = [];
		$seen   = [];

		foreach ($chars as $k => $emoji)
		{
			// Decode entities — the request class html-encodes input, and shortcodes
			// like <3 or >:-) must be stored raw to match what users actually type.
			// The request class has already trimmed the values.
			$emoji = html_entity_decode((string) $emoji, ENT_COMPAT, 'UTF-8');

			if ($emoji === '' || isset($seen[$emoji]))
			{
				continue;
			}

			$raw_codes  = isset($codes[$k]) ? html_entity_decode((string) $codes[$k], ENT_COMPAT, 'UTF-8') : '';
			$shortcodes = [];

			foreach (preg_split('/\s+/', $raw_codes) as $code)
			{
				if ($code !== '' && !in_array($code, $shortcodes, true))
				{
					$shortcodes[] = $code;
				}
			}

			$seen[$emoji] = true;
			$emojis[] = [
				'emoji'			=> $emoji,
				'shortcodes'	=> $shortcodes,
				'in_picker'		=> !empty($picker[$k]),
			];
		}

		return $emojis;
	}

	/**
	 * Build the list of disable-able BBCodes: core defaults plus custom tags.
	 *
	 * @return array
	 */
	private function get_bbcode_list(): array
	{
		$core = ['b', 'i', 'u', 'quote', 'code', 'list', 'img', 'url', 'size', 'color', 'email', 'flash', 'attachment'];

		$custom = [];

		$sql = 'SELECT bbcode_tag FROM ' . BBCODES_TABLE . ' ORDER BY bbcode_tag';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			// Tags defined with an attribute are stored as "tag=" — strip it for disable_bbcode().
			$tag = rtrim((string) $row['bbcode_tag'], '=');

			if ($tag !== '' && !in_array($tag, $core, true))
			{
				$custom[] = $tag;
			}
		}
		$this->db->sql_freeresult($result);

		return array_merge($core, $custom);
	}

	/**
	 * Display ACP settings page
	 *
	 * @return void
	 */
	public function display_options(): void
	{
		if ($this->request->variable('action', '') === 'toggle')
		{
			$this->ajax_toggle_setting();
			return;
		}

		$this->language->add_lang('acp_chat', 'stoker/chat');

		$this->assign_version_check_vars();

		$portal_installed = $this->ext_manager->is_enabled('stoker/portal') && !empty($this->config['acp_portal_enable']);

		add_form_key('stoker_chat_acp');

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key('stoker_chat_acp'))
			{
				trigger_error($this->language->lang('FORM_INVALID'), E_USER_WARNING);
			}

			$index_pos = $this->request->variable('stoker_chat_index_position', 1);
			$portal_pos = $this->request->variable('stoker_chat_portal_position', 1);
			$action_bar = $this->request->variable('stoker_chat_action_bar', 0);
			$flow = $this->request->variable('stoker_chat_flow', 0);
			$max_messages = max(10, min(5000, $this->request->variable('stoker_chat_max_messages', 50)));

			$this->config->set('stoker_chat_index_position', in_array($index_pos, [0, 1], true) ? $index_pos : 1);
			$this->config->set('stoker_chat_portal_position', in_array($portal_pos, [0, 1, 2], true) ? $portal_pos : 1);
			$this->config->set('stoker_chat_action_bar', in_array($action_bar, [0, 1, 2], true) ? $action_bar : 0);
			$this->config->set('stoker_chat_flow', in_array($flow, [0, 1], true) ? $flow : 0);
			$this->config->set('stoker_chat_poll_interval', max(1, min(60, $this->request->variable('stoker_chat_poll_interval', 3))));
			$this->config->set('stoker_chat_max_messages', $max_messages);
			// The initial batch can never exceed the number of messages the chat displays
			$this->config->set('stoker_chat_initial_load', max(0, min(50, $max_messages, $this->request->variable('stoker_chat_initial_load', 10))));
			$this->config->set('stoker_chat_max_length', max(50, min(5000, $this->request->variable('stoker_chat_max_length', 500))));
			$this->config->set('stoker_chat_flood_interval', max(0, min(60, $this->request->variable('stoker_chat_flood_interval', 2))));
			$this->config->set('stoker_chat_purge_days', max(0, min(3650, $this->request->variable('stoker_chat_purge_days', 30))));
			$this->config->set('stoker_chat_inactivity_minutes', max(0, min(1440, $this->request->variable('stoker_chat_inactivity_minutes', 10))));
			$this->config->set('stoker_chat_tabhidden_seconds', max(0, min(3600, $this->request->variable('stoker_chat_tabhidden_seconds', 10))));

			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ACP_STOKER_CHAT_SETTINGS');

			trigger_error($this->language->lang('ACP_STOKER_CHAT_SAVED') . adm_back_link($this->u_action));
		}

		if ($this->request->is_set_post('purge'))
		{
			if (confirm_box(true))
			{
				$this->purge_messages();

				$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ACP_STOKER_CHAT_PURGE');

				trigger_error($this->language->lang('ACP_STOKER_CHAT_PURGED') . adm_back_link($this->u_action));
			}
			else
			{
				confirm_box(false, 'ACP_STOKER_CHAT_PURGE_NOW', build_hidden_fields([
					'purge'	=> 1,
				]));
			}
		}

		// Active count excludes soft-deleted rows. The highest id still includes them until
		// the purge cron hard-deletes the tombstones, after which it can drop.
		$sql = 'SELECT SUM(CASE WHEN deleted = 0 THEN 1 ELSE 0 END) AS total, MAX(message_id) AS highest_id
			FROM ' . $this->chat_table;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$total_messages = (int) $row['total'];
		$highest_id = (int) $row['highest_id'];

		$this->template->assign_vars([
			'U_ACTION'							=> $this->u_action,
			'STOKER_CHAT_INDEX_ENABLE'			=> (int) ($this->config['stoker_chat_index_enable'] ?? 1),
			'STOKER_CHAT_INDEX_POSITION'		=> (int) ($this->config['stoker_chat_index_position'] ?? 1),
			'STOKER_CHAT_PORTAL_ENABLE'			=> (int) ($this->config['stoker_chat_portal_enable'] ?? 1),
			'STOKER_CHAT_PORTAL_POSITION'		=> (int) ($this->config['stoker_chat_portal_position'] ?? 1),
			'STOKER_CHAT_ACTION_BAR'			=> (int) ($this->config['stoker_chat_action_bar'] ?? 0),
			'STOKER_CHAT_FLOW'					=> (int) ($this->config['stoker_chat_flow'] ?? 0),
			'STOKER_CHAT_POLL_INTERVAL'			=> (int) ($this->config['stoker_chat_poll_interval'] ?? 3),
			'STOKER_CHAT_MAX_MESSAGES'			=> (int) ($this->config['stoker_chat_max_messages'] ?? 50),
			'STOKER_CHAT_INITIAL_LOAD'			=> (int) ($this->config['stoker_chat_initial_load'] ?? 10),
			'STOKER_CHAT_MAX_LENGTH'			=> (int) ($this->config['stoker_chat_max_length'] ?? 500),
			'STOKER_CHAT_FLOOD_INTERVAL'		=> (int) ($this->config['stoker_chat_flood_interval'] ?? 2),
			'STOKER_CHAT_PURGE_DAYS'			=> (int) ($this->config['stoker_chat_purge_days'] ?? 30),
			'STOKER_CHAT_INACTIVITY_MINUTES'	=> (int) ($this->config['stoker_chat_inactivity_minutes'] ?? 10),
			'STOKER_CHAT_TABHIDDEN_SECONDS'		=> (int) ($this->config['stoker_chat_tabhidden_seconds'] ?? 10),
			'S_PORTAL_INSTALLED_CHAT'			=> $portal_installed,
			'STOKER_CHAT_TOTAL_MESSAGES'		=> $total_messages,
			'STOKER_CHAT_HIGHEST_ID'			=> $highest_id,
			'U_TOGGLE_INDEX_ENABLE'				=> $this->u_action . '&amp;action=toggle&amp;setting=stoker_chat_index_enable&amp;hash=' . generate_link_hash('togglestoker_chat_index_enable'),
			'U_TOGGLE_PORTAL_ENABLE'			=> $this->u_action . '&amp;action=toggle&amp;setting=stoker_chat_portal_enable&amp;hash=' . generate_link_hash('togglestoker_chat_portal_enable'),
		]);
	}

	/**
	 * @return void
	 */
	private function ajax_toggle_setting(): void
	{
		$setting = $this->request->variable('setting', '');

		$valid_settings = [
			'stoker_chat_index_enable',
			'stoker_chat_portal_enable',
		];

		if (!in_array($setting, $valid_settings, true))
		{
			trigger_error($this->language->lang('FORM_INVALID'), E_USER_WARNING);
		}

		if (!check_link_hash($this->request->variable('hash', ''), 'toggle' . $setting))
		{
			trigger_error($this->language->lang('FORM_INVALID'), E_USER_WARNING);
		}

		$new_value = (int) $this->config[$setting] ? 0 : 1;
		$this->config->set($setting, $new_value);

		$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ACP_STOKER_CHAT_SETTINGS');

		if ($this->request->is_ajax())
		{
			$json_response = new \phpbb\json_response();
			$json_response->send(['success' => true]);
		}

		redirect($this->u_action);
	}

	/**
	 * Soft-delete all messages. The tombstones let open polling clients remove the
	 * messages from their DOM; the purge cron removes them after 24 hours.
	 *
	 * @return void
	 */
	private function purge_messages(): void
	{
		$sql = 'UPDATE ' . $this->chat_table . '
			SET deleted = 1, deleted_time = ' . (int) time() . '
			WHERE deleted = 0';
		$this->db->sql_query($sql);
	}

	/**
	 * Assign version check template variables
	 *
	 * @return void
	 */
	private function assign_version_check_vars(): void
	{
		$md_manager = $this->ext_manager->create_extension_metadata_manager('stoker/chat');

		$current_version = '';
		$version_data = null;

		try
		{
			$meta = $md_manager->get_metadata('all');
			$current_version = (string) ($meta['version'] ?? '');
			$version_data = $meta['extra']['version-check'] ?? null;
		}
		catch (\Exception $e)
		{
			// Fall through, the unavailable branch below handles it
		}

		// Always assigned, the ACP badge reads this on every path
		$this->template->assign_vars([
			'VERSIONCHECK_INSTALLED'	=> $current_version,
		]);

		if (!is_array($version_data) || empty($version_data['host']) || empty($version_data['directory']) || empty($version_data['filename']) || $current_version === '')
		{
			$this->template->assign_vars([
				'S_VERSIONCHECK_UNAVAILABLE'	=> true,
			]);
			return;
		}

		$failed_key = '_stoker_chat_versioncheck_failed';

		// version_helper only caches successful fetches, a failed one is not retried on every page view
		if ($this->cache->get($failed_key))
		{
			$this->template->assign_vars([
				'S_VERSIONCHECK_UNAVAILABLE'	=> true,
			]);
			return;
		}

		$version_helper = new version_helper($this->cache, $this->config, $this->file_downloader);
		$version_helper->set_current_version($current_version);
		$version_helper->set_file_location(
			(string) $version_data['host'],
			(string) $version_data['directory'],
			(string) $version_data['filename'],
			!empty($version_data['ssl'])
		);

		try
		{
			$update = $version_helper->get_ext_update_on_branch();
		}
		catch (\Exception $e)
		{
			$this->cache->put($failed_key, true, self::VERSIONCHECK_RETRY_TTL);

			$this->template->assign_vars([
				'S_VERSIONCHECK_UNAVAILABLE'	=> true,
			]);
			return;
		}

		if (empty($update))
		{
			$this->template->assign_vars([
				'S_VERSIONCHECK_UP_TO_DATE'	=> true,
				'VERSIONCHECK_CURRENT'		=> $current_version,
			]);
			return;
		}

		$this->template->assign_vars([
			'S_VERSIONCHECK_OUTDATED'	=> true,
			'VERSIONCHECK_CURRENT'		=> $current_version,
			'VERSIONCHECK_LATEST'		=> (string) ($update['current'] ?? ''),
			'U_VERSIONCHECK_DOWNLOAD'	=> (string) ($update['download'] ?? ''),
		]);
	}
}
