<?php
/**
 *
 * Chat extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

declare(strict_types=1);

namespace stoker\chat\controller;

use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\controller\helper;
use phpbb\db\driver\driver_interface;
use phpbb\event\dispatcher_interface;
use phpbb\language\language;
use phpbb\path_helper;
use phpbb\request\request;
use phpbb\template\template;
use phpbb\textformatter\renderer_interface;
use phpbb\textformatter\utils_interface;
use phpbb\user;
use stoker\chat\core\chat_helper;
use stoker\chat\core\message_manager;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class main_controller
{
	/** @var auth */
	protected $auth;

	/** @var chat_helper */
	protected $chat_helper;

	/** @var config */
	protected $config;

	/** @var driver_interface */
	protected $db;

	/** @var dispatcher_interface */
	protected $dispatcher;

	/** @var helper */
	protected $helper;

	/** @var language */
	protected $language;

	/** @var message_manager */
	protected $message_manager;

	/** @var path_helper */
	protected $path_helper;

	/** @var renderer_interface */
	protected $renderer;

	/** @var utils_interface */
	protected $utils;

	/** @var request */
	protected $request;

	/** @var template */
	protected $template;

	/** @var user */
	protected $user;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $chat_table;

	/** @var string|null Memoised default avatar HTML, built lazily on first use. */
	protected $default_avatar_html = null;

	/** @var array<int, string> Per-request cache of resolved avatar HTML keyed by user_id. */
	protected $avatar_cache = [];

	/**
	 * @param auth                 $auth
	 * @param chat_helper          $chat_helper
	 * @param config               $config
	 * @param driver_interface     $db
	 * @param dispatcher_interface $dispatcher
	 * @param helper               $helper
	 * @param language             $language
	 * @param message_manager      $message_manager
	 * @param path_helper          $path_helper
	 * @param renderer_interface   $renderer
	 * @param utils_interface      $utils
	 * @param request              $request
	 * @param template             $template
	 * @param user                 $user
	 * @param string               $root_path
	 * @param string               $chat_table
	 */
	public function __construct(auth $auth, chat_helper $chat_helper, config $config, driver_interface $db, dispatcher_interface $dispatcher, helper $helper, language $language, message_manager $message_manager, path_helper $path_helper, renderer_interface $renderer, utils_interface $utils, request $request, template $template, user $user, string $root_path, string $chat_table)
	{
		$this->auth = $auth;
		$this->chat_helper = $chat_helper;
		$this->config = $config;
		$this->db = $db;
		$this->dispatcher = $dispatcher;
		$this->helper = $helper;
		$this->language = $language;
		$this->message_manager = $message_manager;
		$this->path_helper = $path_helper;
		$this->renderer = $renderer;
		$this->utils = $utils;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->root_path = $root_path;
		$this->chat_table = $chat_table;
	}

	/**
	 * Display the standalone chat page
	 *
	 * @return Response
	 */
	public function display(): Response
	{
		if (!$this->auth->acl_get('u_stoker_chat_view'))
		{
			throw new \phpbb\exception\http_exception(403, 'NOT_AUTHORISED');
		}

		$this->language->add_lang('common', 'stoker/chat');

		$this->template->assign_block_vars('navlinks', [
			'FORUM_NAME'	=> $this->language->lang('STOKER_CHAT_TITLE'),
			'U_VIEW_FORUM'	=> $this->helper->route('stoker_chat_page'),
		]);

		$this->template->assign_vars($this->chat_helper->get_chat_vars(true));

		return $this->helper->render('chat_body.html', $this->language->lang('STOKER_CHAT_TITLE'), 200, true);
	}

	/**
	 * Fetch messages. Three modes:
	 *  - delta:   last_id > 0           → new messages, plus edits/deletes since last_check within visible range
	 *  - older:   before_id > 0         → batch of messages older than before_id (load more)
	 *  - initial: neither set           → newest N messages (page open)
	 *
	 * All modes filter out soft-deleted rows from message content. Delta mode also reports
	 * deletions in a separate "deleted" array so the client can remove them from the DOM.
	 * Each response carries a "now" timestamp the client passes back as last_check next poll.
	 *
	 * @return JsonResponse
	 */
	public function fetch(): JsonResponse
	{
		// JSON responses never reach page_header(), so keep the session alive here
		$this->user->update_session_infos();

		$this->language->add_lang('common', 'stoker/chat');

		if (!$this->auth->acl_get('u_stoker_chat_view'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		$last_id = $this->request->variable('last_id', 0);
		$before_id = $this->request->variable('before_id', 0);
		$last_check = $this->request->variable('last_check', 0);
		$oldest = $this->request->variable('oldest_visible_id', 0);
		$max_messages = (int) $this->config['stoker_chat_max_messages'];
		$initial_load = (int) $this->config['stoker_chat_initial_load'];
		$now = time();
		$perms = $this->resolve_perms();

		if ($last_id > 0)
		{
			// Delta poll. The extra row shows whether more new messages exist than the chat
			// displays (e.g. after a lockdown); the client then replaces its rows with the newest.
			$messages = $this->get_messages($last_id, $max_messages + 1, $perms);
			$gap = count($messages) > $max_messages;
			if ($gap)
			{
				array_shift($messages);
			}

			$response = [
				'messages'	=> $messages,
				'now'		=> $now,
			];

			if ($gap)
			{
				$response['gap'] = true;
				$response['has_more'] = true;
			}
			else if ($last_check > 0 && $oldest > 0 && $oldest <= $last_id)
			{
				// The visible range comes from the client: cap its span so a forged or very
				// old oldest_visible_id cannot turn every delta poll into a full table scan.
				$oldest = max($oldest, $last_id - 2 * $max_messages);

				// Overlap the watermark by one second: an edit/delete committed in the
				// same wall-clock second as the previous poll's "now" would otherwise
				// be missed. Re-reporting within this 1s window is idempotent client-side.
				$since = $last_check - 1;
				$response['edited'] = $this->get_changed_messages($oldest, $last_id, $since, $perms);
				$response['deleted'] = $this->get_deleted_ids($oldest, $last_id, $since);
			}

			return $this->respond($response, 'delta');
		}

		if ($before_id > 0)
		{
			// Load older batch
			$batch_size = $initial_load > 0 ? $initial_load : $max_messages;
			$messages = $this->get_messages_before($before_id, $batch_size + 1, $perms);
			$has_more = count($messages) > $batch_size;
			if ($has_more)
			{
				array_shift($messages);
			}

			return $this->respond([
				'messages'	=> $messages,
				'has_more'	=> $has_more,
				'now'		=> $now,
			], 'older');
		}

		// Initial load
		$limit = $initial_load > 0 ? $initial_load : $max_messages;
		$messages = $this->get_messages(0, $limit + 1, $perms);
		$has_more = count($messages) > $limit;
		if ($has_more)
		{
			array_shift($messages);

			// "Load older" is only offered when the initial-load feature is enabled.
			$has_more = $initial_load > 0;
		}

		return $this->respond([
			'messages'	=> $messages,
			'has_more'	=> $has_more,
			'now'		=> $now,
		], 'initial');
	}

	/**
	 * Post a new chat message
	 *
	 * @return JsonResponse
	 */
	public function post(): JsonResponse
	{
		$this->user->update_session_infos();

		$this->language->add_lang('common', 'stoker/chat');

		if (!$this->auth->acl_get('u_stoker_chat_view') || !$this->auth->acl_get('u_stoker_chat_use'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		if ((int) $this->user->data['user_id'] === ANONYMOUS)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_LOGIN')]);
		}

		if (!check_link_hash($this->request->variable('hash', ''), 'stoker_chat'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('FORM_INVALID')]);
		}

		$message = $this->request->variable('message', '', true);
		$message = html_entity_decode($message, ENT_COMPAT, 'UTF-8');
		$user_id = (int) $this->user->data['user_id'];
		$error = '';

		/**
		 * Modify or reject a chat message before it is validated and stored.
		 * Fires before validation and the flood check, so the post may still be
		 * rejected afterwards: do not perform side effects here, use post_after.
		 *
		 * @event stoker.chat.post_before
		 * @var string message Raw message text
		 * @var int    user_id Poster user ID (read-only, changes are ignored)
		 * @var string error   Set to a localised error string to reject the post
		 * @since 2.1.0
		 */
		$vars = ['message', 'user_id', 'error'];
		extract($this->dispatcher->trigger_event('stoker.chat.post_before', compact($vars)));

		if ($error !== '')
		{
			return new JsonResponse(['success' => false, 'error' => $error]);
		}

		// The author is always the session user, whatever a listener did to user_id
		$user_id = (int) $this->user->data['user_id'];
		$message = trim((string) $message, " \n\r\t\v\x00");

		$validation = $this->validate_message($message);
		if ($validation !== null)
		{
			return new JsonResponse(['success' => false, 'error' => $validation]);
		}

		$disallowed = $this->find_disallowed_bbcode($message);
		if ($disallowed !== null)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_BBCODE_NOT_ALLOWED', $disallowed)]);
		}

		if (!$this->auth->acl_get('u_stoker_chat_noflood'))
		{
			$flood = (int) $this->config['stoker_chat_flood_interval'];
			if ($flood > 0)
			{
				$last = $this->get_user_last_post_time($user_id);
				$wait = ($last + $flood) - time();
				if ($wait > 0)
				{
					return new JsonResponse([
						'success'	=> false,
						'error'		=> $this->language->lang('STOKER_CHAT_FLOOD', $wait),
					]);
				}
			}
		}

		$validated = $message;
		$handled = false;

		/**
		 * Handle a validated chat message instead of storing it, e.g. a chat command.
		 * Fires after validation and the flood check. A handled message is not stored,
		 * so it does not count toward the flood interval and post_after does not fire:
		 * listeners must rate-limit their own commands.
		 *
		 * @event stoker.chat.post_handle
		 * @var string message Raw message text (read-only, changes are ignored)
		 * @var int    user_id Poster user ID (read-only, changes are ignored)
		 * @var bool   handled Set to true to skip storing the message
		 * @var string error   Set to a localised error string to reject the post
		 * @since 2.1.0
		 */
		$vars = ['message', 'user_id', 'handled', 'error'];
		extract($this->dispatcher->trigger_event('stoker.chat.post_handle', compact($vars)));

		// Validation has run, so listener changes to the message or author are discarded
		$user_id = (int) $this->user->data['user_id'];
		$message = $validated;

		if ($error !== '')
		{
			return new JsonResponse(['success' => false, 'error' => $error]);
		}

		if ($handled)
		{
			return new JsonResponse(['success' => true]);
		}

		$message_id = $this->message_manager->add_message($user_id, $message);

		/**
		 * Event after a chat message has been stored
		 *
		 * @event stoker.chat.post_after
		 * @var int    message_id New message ID
		 * @var int    user_id    Poster user ID
		 * @var string message    Raw message text
		 * @since 2.1.0
		 */
		$vars = ['message_id', 'user_id', 'message'];
		extract($this->dispatcher->trigger_event('stoker.chat.post_after', compact($vars)));

		return new JsonResponse([
			'success'		=> true,
			'message_id'	=> (int) $message_id,
		]);
	}

	/**
	 * Edit an existing chat message
	 *
	 * @return JsonResponse
	 */
	public function edit(): JsonResponse
	{
		$this->user->update_session_infos();

		$this->language->add_lang('common', 'stoker/chat');

		if (!$this->auth->acl_get('u_stoker_chat_view') || !$this->auth->acl_get('u_stoker_chat_use'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		if ((int) $this->user->data['user_id'] === ANONYMOUS)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_LOGIN')]);
		}

		if (!check_link_hash($this->request->variable('hash', ''), 'stoker_chat'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('FORM_INVALID')]);
		}

		$message_id = $this->request->variable('message_id', 0);
		$message = $this->request->variable('message', '', true);
		$message = html_entity_decode($message, ENT_COMPAT, 'UTF-8');

		if ($message_id <= 0)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_INVALID_ID')]);
		}

		$user_id = (int) $this->user->data['user_id'];
		$error = '';

		/**
		 * Modify or reject an edited chat message before it is validated and stored.
		 * Fires before validation and the permission check, so the edit may still be
		 * rejected afterwards: do not perform side effects here, use edit_after.
		 *
		 * @event stoker.chat.edit_before
		 * @var int    message_id Message ID being edited
		 * @var string message    Raw message text
		 * @var int    user_id    Editor user ID (read-only, changes are ignored)
		 * @var string error      Set to a localised error string to reject the edit
		 * @since 2.1.0
		 */
		$vars = ['message_id', 'message', 'user_id', 'error'];
		extract($this->dispatcher->trigger_event('stoker.chat.edit_before', compact($vars)));

		if ($error !== '')
		{
			return new JsonResponse(['success' => false, 'error' => $error]);
		}

		// The editor is always the session user, whatever a listener did to user_id
		$user_id = (int) $this->user->data['user_id'];
		$message_id = (int) $message_id;
		$message = trim((string) $message, " \n\r\t\v\x00");

		$validation = $this->validate_message($message);
		if ($validation !== null)
		{
			return new JsonResponse(['success' => false, 'error' => $validation]);
		}

		$disallowed = $this->find_disallowed_bbcode($message);
		if ($disallowed !== null)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_BBCODE_NOT_ALLOWED', $disallowed)]);
		}

		$row = $this->get_message_row($message_id);
		if ($row === null)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_FOUND')]);
		}

		if (!$this->can_modify($row, 'u_stoker_chat_edit'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		$stored = $this->message_manager->parse($message);
		$now = time();

		$sql_ary = [
			'message'	=> $stored,
			'edit_time'	=> $now,
		];

		$sql = 'UPDATE ' . $this->chat_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE message_id = ' . (int) $message_id . '
				AND deleted = 0';
		$this->db->sql_query($sql);

		/**
		 * Event after a chat message has been edited
		 *
		 * @event stoker.chat.edit_after
		 * @var int    message_id Edited message ID
		 * @var int    user_id    Editor user ID
		 * @var string message    Raw message text
		 * @var array  row        Message row before the edit (message_id, user_id)
		 * @since 2.1.0
		 */
		$vars = ['message_id', 'user_id', 'message', 'row'];
		extract($this->dispatcher->trigger_event('stoker.chat.edit_after', compact($vars)));

		return new JsonResponse([
			'success'		=> true,
			'message_id'	=> (int) $message_id,
			'message'		=> $this->renderer->render($stored),
			'raw'			=> $this->utils->unparse($stored),
			'edit_time'		=> $now,
		]);
	}

	/**
	 * Delete a chat message
	 *
	 * @return JsonResponse
	 */
	public function delete(): JsonResponse
	{
		$this->user->update_session_infos();

		$this->language->add_lang('common', 'stoker/chat');

		if (!$this->auth->acl_get('u_stoker_chat_view') || !$this->auth->acl_get('u_stoker_chat_use'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		if ((int) $this->user->data['user_id'] === ANONYMOUS)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_LOGIN')]);
		}

		if (!check_link_hash($this->request->variable('hash', ''), 'stoker_chat'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('FORM_INVALID')]);
		}

		$message_id = $this->request->variable('message_id', 0);

		if ($message_id <= 0)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_INVALID_ID')]);
		}

		$row = $this->get_message_row($message_id);
		if ($row === null)
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_FOUND')]);
		}

		if (!$this->can_modify($row, 'u_stoker_chat_delete'))
		{
			return new JsonResponse(['success' => false, 'error' => $this->language->lang('STOKER_CHAT_NOT_AUTHORISED')]);
		}

		$now = time();
		$sql = 'UPDATE ' . $this->chat_table . '
			SET deleted = 1, deleted_time = ' . (int) $now . '
			WHERE message_id = ' . (int) $message_id . '
				AND deleted = 0';
		$this->db->sql_query($sql);

		$user_id = (int) $this->user->data['user_id'];

		/**
		 * Event after a chat message has been soft-deleted
		 *
		 * @event stoker.chat.delete_after
		 * @var int   message_id Deleted message ID
		 * @var int   user_id    User ID of who deleted it
		 * @var array row        Message row (message_id, user_id of the author)
		 * @since 2.1.0
		 */
		$vars = ['message_id', 'user_id', 'row'];
		extract($this->dispatcher->trigger_event('stoker.chat.delete_after', compact($vars)));

		return new JsonResponse(['success' => true]);
	}

	/**
	 * Get messages from the database, returned in chronological order. With $last_id
	 * set, the newest $limit messages after it; otherwise the newest $limit messages.
	 *
	 * @param int   $last_id
	 * @param int   $limit
	 * @param array $perms Pre-resolved permission flags from resolve_perms().
	 * @return array
	 */
	public function get_messages(int $last_id = 0, int $limit = 50, array $perms = []): array
	{
		if (empty($perms))
		{
			$perms = $this->resolve_perms();
		}

		$where = ['m.deleted = 0'];
		if ($last_id > 0)
		{
			$where[] = 'm.message_id > ' . (int) $last_id;
		}

		$sql = 'SELECT m.message_id, m.user_id, m.message, m.message_time, m.edit_time,
				u.username, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height
			FROM ' . $this->chat_table . ' m
			LEFT JOIN ' . USERS_TABLE . ' u ON m.user_id = u.user_id
			WHERE ' . implode(' AND ', $where) . '
			ORDER BY m.message_id DESC';
		$result = $this->db->sql_query_limit($sql, $limit);

		$messages = $rows = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$messages[] = $this->format_row($row, $perms);
			$rows[] = $row;
		}
		$this->db->sql_freeresult($result);

		return $this->modify_messages(array_reverse($messages), array_reverse($rows), $last_id > 0 ? 'new' : 'initial');
	}

	/**
	 * Get a batch of messages older than the given id, returned in chronological order.
	 *
	 * @param int   $before_id
	 * @param int   $limit
	 * @param array $perms Pre-resolved permission flags from resolve_perms().
	 * @return array
	 */
	public function get_messages_before(int $before_id, int $limit, array $perms = []): array
	{
		if (empty($perms))
		{
			$perms = $this->resolve_perms();
		}

		$sql = 'SELECT m.message_id, m.user_id, m.message, m.message_time, m.edit_time,
				u.username, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height
			FROM ' . $this->chat_table . ' m
			LEFT JOIN ' . USERS_TABLE . ' u ON m.user_id = u.user_id
			WHERE m.message_id < ' . (int) $before_id . '
				AND m.deleted = 0
			ORDER BY m.message_id DESC';
		$result = $this->db->sql_query_limit($sql, $limit);

		$messages = $rows = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$messages[] = $this->format_row($row, $perms);
			$rows[] = $row;
		}
		$this->db->sql_freeresult($result);

		return $this->modify_messages(array_reverse($messages), array_reverse($rows), 'older');
	}

	/**
	 * Get messages within the visible range that have been edited since $since.
	 * The range and timestamp come from the client, so the result is capped at
	 * the max-messages setting to bound the per-request rendering cost.
	 *
	 * @param int   $from_id    Oldest visible id (inclusive)
	 * @param int   $to_id      Newest seen id (inclusive)
	 * @param int   $since      Unix timestamp of last poll
	 * @param array $perms      Pre-resolved permission flags from resolve_perms().
	 * @return array
	 */
	public function get_changed_messages(int $from_id, int $to_id, int $since, array $perms = []): array
	{
		if (empty($perms))
		{
			$perms = $this->resolve_perms();
		}

		$sql = 'SELECT m.message_id, m.user_id, m.message, m.message_time, m.edit_time,
				u.username, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height
			FROM ' . $this->chat_table . ' m
			LEFT JOIN ' . USERS_TABLE . ' u ON m.user_id = u.user_id
			WHERE m.message_id >= ' . (int) $from_id . '
				AND m.message_id <= ' . (int) $to_id . '
				AND m.deleted = 0
				AND m.edit_time > ' . (int) $since . '
			ORDER BY m.message_id ASC';
		$result = $this->db->sql_query_limit($sql, max(1, (int) $this->config['stoker_chat_max_messages']));

		$messages = $rows = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$messages[] = $this->format_row($row, $perms);
			$rows[] = $row;
		}
		$this->db->sql_freeresult($result);

		return $this->modify_messages($messages, $rows, 'edited');
	}

	/**
	 * Get IDs of messages within the visible range that have been soft-deleted since $since.
	 * The range comes from the client, so the result is capped at the max-messages
	 * setting, newest first, as the newest rows are the ones most likely on screen.
	 *
	 * @param int $from_id    Oldest visible id (inclusive)
	 * @param int $to_id      Newest seen id (inclusive)
	 * @param int $since      Unix timestamp of last poll
	 * @return int[]
	 */
	public function get_deleted_ids(int $from_id, int $to_id, int $since): array
	{
		$sql = 'SELECT message_id
			FROM ' . $this->chat_table . '
			WHERE message_id >= ' . (int) $from_id . '
				AND message_id <= ' . (int) $to_id . '
				AND deleted = 1
				AND deleted_time > ' . (int) $since . '
			ORDER BY message_id DESC';
		$result = $this->db->sql_query_limit($sql, max(1, (int) $this->config['stoker_chat_max_messages']));

		$ids = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$ids[] = (int) $row['message_id'];
		}
		$this->db->sql_freeresult($result);

		return $ids;
	}

	/**
	 * Let extensions add data to a batch of formatted messages. Empty batches,
	 * the common case for delta polls, skip the event entirely.
	 *
	 * @param array  $messages Formatted messages
	 * @param array  $rows     Raw database rows, same order as $messages
	 * @param string $mode     initial, new, older or edited
	 * @return array
	 */
	protected function modify_messages(array $messages, array $rows, string $mode): array
	{
		if (empty($messages))
		{
			return $messages;
		}

		$core_messages = $messages;

		/**
		 * Add data to a batch of chat messages before they are sent to the client.
		 * Fires on polls from every open chat, so keep listeners cheap. Put addon
		 * data under your own key; messages cannot be removed or reordered and
		 * core keys cannot be overwritten.
		 *
		 * @event stoker.chat.modify_messages
		 * @var array  messages Formatted messages
		 * @var array  rows     Raw database rows, same order as messages
		 * @var string mode     initial, new, older or edited
		 * @since 2.1.0
		 */
		$vars = ['messages', 'rows', 'mode'];
		extract($this->dispatcher->trigger_event('stoker.chat.modify_messages', compact($vars)));

		$result = [];
		foreach ($core_messages as $i => $core)
		{
			$extra = (isset($messages[$i]) && is_array($messages[$i])) ? $messages[$i] : [];
			$result[] = array_merge($extra, $core);
		}

		return $result;
	}

	/**
	 * Let extensions add data to a fetch response, then build the JSON response.
	 *
	 * @param array  $response
	 * @param string $mode initial, delta or older
	 * @return JsonResponse
	 */
	protected function respond(array $response, string $mode): JsonResponse
	{
		$core_response = $response;

		/**
		 * Add data to a fetch response. Fires on every poll from every open chat,
		 * so keep listeners cheap and payloads small. Core keys cannot be overwritten.
		 *
		 * @event stoker.chat.fetch_response
		 * @var array  response Response data
		 * @var string mode     initial, delta or older
		 * @since 2.1.0
		 */
		$vars = ['response', 'mode'];
		extract($this->dispatcher->trigger_event('stoker.chat.fetch_response', compact($vars)));

		return new JsonResponse(array_merge($response, $core_response));
	}

	/**
	 * Resolve all permission flags needed by format_row a single time per request.
	 *
	 * @return array
	 */
	protected function resolve_perms(): array
	{
		$current_id = (int) $this->user->data['user_id'];
		$is_guest = $current_id === ANONYMOUS;
		$can_use = !$is_guest && (bool) $this->auth->acl_get('u_stoker_chat_use');

		return [
			'current_id'	=> $current_id,
			'can_use'		=> $can_use,
			'can_mod'		=> (bool) $this->auth->acl_get('m_stoker_chat_moderate'),
			'can_edit'		=> (bool) $this->auth->acl_get('u_stoker_chat_edit'),
			'can_delete'	=> (bool) $this->auth->acl_get('u_stoker_chat_delete'),
			'can_quote'		=> $can_use && (bool) $this->auth->acl_get('u_stoker_chat_quote'),
			'can_like'		=> $can_use && (bool) $this->auth->acl_get('u_stoker_chat_like'),
		];
	}

	/**
	 * Format a raw database row into the array shape returned by the JSON endpoints.
	 *
	 * @param array $row
	 * @param array $perms Pre-resolved permission flags from resolve_perms().
	 * @return array
	 */
	protected function format_row(array $row, array $perms): array
	{
		$is_owner = $perms['current_id'] !== ANONYMOUS && (int) $row['user_id'] === $perms['current_id'];
		$can_edit = $perms['can_use'] && (($is_owner && $perms['can_edit']) || $perms['can_mod']);
		$can_delete = $perms['can_use'] && (($is_owner && $perms['can_delete']) || $perms['can_mod']);

		// Usernames are stored HTML-escaped; decode so the client escapes exactly once.
		// A NULL username means the author's account no longer exists; ANONYMOUS is the
		// author of system messages. Both show the localised guest name.
		$username = ($row['username'] === null || (int) $row['user_id'] === ANONYMOUS)
			? $this->language->lang('GUEST')
			: htmlspecialchars_decode((string) $row['username'], ENT_COMPAT);

		$out = [
			'message_id'	=> (int) $row['message_id'],
			'username'		=> $username,
			'user_colour'	=> (string) ($row['user_colour'] ?? ''),
			'avatar'		=> $this->resolve_avatar($row),
			'message'		=> $this->renderer->render($row['message']),
			'time_format'	=> $this->user->format_date((int) $row['message_time']),
			'edit_time'		=> (int) $row['edit_time'],
			'can_edit'		=> $can_edit,
			'can_delete'	=> $can_delete,
			'can_quote'		=> $perms['can_quote'],
			'can_like'		=> $perms['can_like'],
		];

		// raw BBCode source is only needed when the viewer can edit this row.
		if ($can_edit)
		{
			$out['raw'] = $this->utils->unparse($row['message']);
		}

		return $out;
	}

	/**
	 * Validate a raw (unescaped) message. Returns null if valid, or a language-localised error string.
	 *
	 * @param string $message
	 * @return string|null
	 */
	protected function validate_message(string $message): ?string
	{
		if ($message === '')
		{
			return $this->language->lang('STOKER_CHAT_EMPTY');
		}

		$max_length = (int) $this->config['stoker_chat_max_length'];
		if (utf8_strlen($message) > $max_length)
		{
			return $this->language->lang('STOKER_CHAT_TOO_LONG');
		}

		return null;
	}

	/**
	 * Return the first disallowed BBCode tag found in the raw message, or null if none.
	 * Matches opening ([tag], [tag=…], [tag name=…]) and closing ([/tag]) forms, case-insensitively.
	 *
	 * @param string $message
	 * @return string|null
	 */
	protected function find_disallowed_bbcode(string $message): ?string
	{
		if (strpos($message, '[') === false)
		{
			return null;
		}

		$disabled = $this->chat_helper->get_emoji_bbcode_set()['disabled_bbcodes'];
		if (empty($disabled))
		{
			return null;
		}

		$tags = array_map(
			static function ($tag)
			{
				return preg_quote((string) $tag, '/');
			},
			$disabled
		);

		if (preg_match('/\[\/?(' . implode('|', $tags) . ')(?:[\s=][^\]]*)?\]/i', $message, $match))
		{
			return strtolower($match[1]);
		}

		return null;
	}

	/**
	 * Fetch a single message row for ownership check. Returns null if not found.
	 *
	 * @param int $message_id
	 * @return array|null
	 */
	protected function get_message_row(int $message_id): ?array
	{
		$sql = 'SELECT message_id, user_id
			FROM ' . $this->chat_table . '
			WHERE message_id = ' . (int) $message_id . '
				AND deleted = 0';
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		return $row === false ? null : $row;
	}

	/**
	 * True if the current user may modify the given message row. Moderators
	 * always may; the owner additionally needs the given permission.
	 *
	 * @param array  $row
	 * @param string $permission
	 * @return bool
	 */
	protected function can_modify(array $row, string $permission): bool
	{
		if ($this->auth->acl_get('m_stoker_chat_moderate'))
		{
			return true;
		}

		return (int) $row['user_id'] === (int) $this->user->data['user_id']
			&& (bool) $this->auth->acl_get($permission);
	}

	/**
	 * Get the timestamp of the given user's most recent chat message.
	 * Soft-deleted rows count too, so deleting a message cannot reset the flood timer.
	 *
	 * @param int $user_id
	 * @return int
	 */
	protected function get_user_last_post_time(int $user_id): int
	{
		$sql = 'SELECT MAX(message_time) AS last_time
			FROM ' . $this->chat_table . '
			WHERE user_id = ' . (int) $user_id;
		$result = $this->db->sql_query($sql);
		$last = (int) $this->db->sql_fetchfield('last_time');
		$this->db->sql_freeresult($result);

		return $last;
	}

	/**
	 * Return the user's avatar HTML, or an <img> pointing to the default avatar when empty.
	 *
	 * @param array $row
	 * @return string
	 */
	protected function resolve_avatar(array $row): string
	{
		$user_id = (int) $row['user_id'];
		if (isset($this->avatar_cache[$user_id]))
		{
			return $this->avatar_cache[$user_id];
		}

		$avatar = phpbb_get_user_avatar($row);
		if ($avatar === '')
		{
			if ($this->default_avatar_html === null)
			{
				$src = $this->path_helper->update_web_root_path(
					$this->root_path . 'ext/stoker/chat/styles/prosilver/theme/images/default_avatar.png'
				);
				$this->default_avatar_html = '<img class="avatar" src="' . $src . '" width="32" height="32" alt="">';
			}
			$avatar = $this->default_avatar_html;
		}

		$this->avatar_cache[$user_id] = $avatar;
		return $avatar;
	}
}
